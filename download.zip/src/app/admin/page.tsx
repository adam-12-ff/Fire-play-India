
'use client';

import { useEffect, useState } from 'react';
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth, db } from '@/lib/firebase';
import { doc, getDoc, setDoc, onSnapshot, collection, query, where, getDocs, updateDoc } from 'firebase/firestore';
import { useRouter } from 'next/navigation';
import { Loader2, ShieldAlert, UserSearch, CheckCircle, Copy, LogOut } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { FirePlayCard } from '@/components/profile/fire-play-card';

type SearchedUser = {
  id: string;
  name: string;
  phone: string;
  isVerified: boolean;
  verificationCode?: string;
  [key: string]: any; // To allow for other user properties
};

export default function AdminPage() {
  const { toast } = useToast();
  const router = useRouter();
  
  const [phoneSearch, setPhoneSearch] = useState('');
  const [searchedUser, setSearchedUser] = useState<SearchedUser | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [isGeneratingCode, setIsGeneratingCode] = useState(false);
  
  const handleSearchUser = async () => {
    if (!phoneSearch) {
        toast({ variant: 'destructive', title: 'Phone number required' });
        return;
    }
    setIsSearching(true);
    setSearchedUser(null);
    try {
        const usersRef = collection(db, 'users');
        const q = query(usersRef, where('phone', '==', phoneSearch));
        const querySnapshot = await getDocs(q);

        if (querySnapshot.empty) {
            toast({ variant: 'destructive', title: 'User Not Found', description: 'No user registered with this phone number.' });
        } else {
            const userDoc = querySnapshot.docs[0];
            const userData = userDoc.data();
            setSearchedUser({ 
              id: userDoc.id, 
              ...userData, 
            });
        }
    } catch (error) {
        toast({ variant: 'destructive', title: 'Search Failed', description: 'An error occurred while searching for the user.' });
    } finally {
        setIsSearching(false);
    }
  }
  
  const generateVerificationCode = async () => {
    if (!searchedUser) return;
    setIsGeneratingCode(true);

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    try {
        const userDocRef = doc(db, 'users', searchedUser.id);
        await updateDoc(userDocRef, { verificationCode: code });
        
        setSearchedUser(prev => prev ? { ...prev, verificationCode: code } : null);
        
        toast({ title: 'Code Generated!', description: 'The verification code has been created and saved.' });
    } catch(error) {
        toast({ variant: 'destructive', title: 'Code Generation Failed' });
    } finally {
        setIsGeneratingCode(false);
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied to clipboard!' });
  };
  
  const handleLogout = async () => {
    await auth.signOut();
    router.push('/login');
  }


  return (
    <div className="container max-w-4xl px-4 py-6 sm:px-6 space-y-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold font-headline">Admin Panel</h1>
          <p className="text-muted-foreground">Manage FirePlay global settings & users</p>
        </div>
        <Button variant="destructive" onClick={handleLogout}>
            <LogOut /> Logout
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
            <CardHeader>
                <CardTitle>User Verification</CardTitle>
                <CardDescription>Search for a user by their phone number to generate a verification code.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex gap-2">
                    <Input 
                        type="tel" 
                        placeholder="Enter user's phone number" 
                        value={phoneSearch}
                        onChange={(e) => setPhoneSearch(e.target.value)}
                    />
                    <Button onClick={handleSearchUser} disabled={isSearching}>
                        {isSearching ? <Loader2 className="animate-spin" /> : <UserSearch />}
                    </Button>
                </div>
                
                {searchedUser && (
                    <div className="space-y-4">
                      <FirePlayCard userData={searchedUser} showVerificationButton={false} />
                      
                      {searchedUser.isVerified ? (
                           <Alert className="border-green-500/30 bg-green-500/10 text-green-400">
                              <CheckCircle className="h-4 w-4 text-current" />
                              <AlertTitle>User is already verified</AlertTitle>
                          </Alert>
                      ) : (
                          <Card className="bg-secondary/30">
                              <CardContent className="p-4 space-y-4">
                                  {searchedUser.verificationCode && (
                                       <div className="space-y-2">
                                          <Label>Generated Verification Code</Label>
                                          <div className="flex items-center gap-2">
                                              <Input readOnly value={searchedUser.verificationCode} className="font-mono" />
                                              <Button size="icon" variant="outline" onClick={() => copyToClipboard(searchedUser.verificationCode!)}>
                                                  <Copy />
                                              </Button>
                                          </div>
                                           <p className="text-xs text-muted-foreground">Send this code to the user on WhatsApp.</p>
                                       </div>
                                  )}
                                  <Button onClick={generateVerificationCode} disabled={isGeneratingCode} className="w-full btn-glow">
                                      {isGeneratingCode ? <Loader2 className="animate-spin" /> : 'Generate New Code'}
                                  </Button>
                              </CardContent>
                          </Card>
                      )}
                    </div>
                )}
            </CardContent>
        </Card>
        
        <Card>
           <CardHeader>
               <CardTitle>All Users</CardTitle>
               <CardDescription>View and manage all registered users.</CardDescription>
            </CardHeader>
            <CardContent>
                <p className="text-center text-muted-foreground py-8">User management coming soon.</p>
            </CardContent>
        </Card>
      </div>
    </div>
  );
}
