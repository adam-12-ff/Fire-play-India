
'use client';

import { useState, useRef } from 'react';
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { auth, db } from '@/lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { Loader2, Upload, ScanSearch } from 'lucide-react';
import { extractProfileDetailsFromScreenshot } from '@/ai/flows/ocr-profile-details';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const signupSchema = z.object({
  name: z.string().min(3, "Name must be at least 3 characters."),
  phone: z.string().min(10, "Please enter a valid phone number."),
  password: z.string().min(6, "Password must be at least 6 characters."),
  gameUid: z.string().optional(),
  level: z.string().optional(),
  username: z.string().optional(),
});

type SignupFormValues = z.infer<typeof signupSchema>;

// This is the designated phone number for the admin account
const ADMIN_PHONE_NUMBER = "1234567890";

export default function SignupPage() {
  const { toast } = useToast();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [step, setStep] = useState(1);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [screenshotFile, setScreenshotFile] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);

  const form = useForm<SignupFormValues>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      name: "",
      phone: "",
      password: "",
      gameUid: "",
      level: "",
      username: "",
    },
  });
  
  const handleNextStep = async () => {
    const isValid = await form.trigger(["name", "phone", "password"]);
    if (isValid) {
      setStep(2);
    }
  }

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setScreenshotFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshotPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleVerifyScreenshot = async () => {
    if (!screenshotFile) {
      toast({ variant: 'destructive', title: 'No Screenshot', description: 'Please upload a screenshot first.' });
      return;
    }
    setIsVerifying(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(screenshotFile);
      reader.onload = async (e) => {
        const screenshotDataUri = e.target?.result as string;
        const result = await extractProfileDetailsFromScreenshot({ screenshotDataUri });
        
        form.setValue('gameUid', result.uid, { shouldValidate: true });
        form.setValue('level', result.level, { shouldValidate: true });
        form.setValue('username', result.username, { shouldValidate: true });
        
        toast({ title: 'Verification Complete', description: 'UID and Level have been extracted.' });
      };
    } catch (error) {
       toast({ variant: 'destructive', title: 'Verification Failed', description: 'Could not extract details from the screenshot.' });
    } finally {
        setIsVerifying(false);
    }
  };

  const onSubmit = async (data: SignupFormValues) => {
    setIsLoading(true);
    try {
      // Create a dummy email for Firebase auth
      const email = `${data.phone}@fireplay.com`;
      const userCredential = await createUserWithEmailAndPassword(auth, email, data.password);
      const user = userCredential.user;

      // Update Firebase Auth profile
      await updateProfile(user, { displayName: data.name });

      // Check if the registered phone number is the admin number
      const isAdmin = data.phone === ADMIN_PHONE_NUMBER;

      // Create user document in Firestore
      await setDoc(doc(db, "users", user.uid), {
        uid: user.uid,
        name: data.name,
        phone: data.phone,
        email: user.email,
        fireplayId: `FPID-${user.uid.substring(0, 8).toUpperCase()}`,
        isVerified: false,
        isAdmin: isAdmin, // Set isAdmin based on phone number
        rank: 'Bronze I',
        gameUid: data.gameUid,
        level: data.level,
        username: data.username,
        walletBalance: 0,
        realMoneyBalance: 0,
        createdAt: new Date(),
      });
      
      toast({
        title: "Account Created!",
        description: "Welcome to FirePlay. Please log in.",
      });
      router.push('/login');
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: "Signup Failed",
        description: error.message || "Could not create your account.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="border-primary/20 shadow-xl shadow-primary/10">
      <CardHeader className="text-center">
        <CardTitle className="text-3xl font-headline tracking-tight">
          {step === 1 ? 'Join the Arena' : 'Gaming Profile'}
        </CardTitle>
        <CardDescription>
          {step === 1 ? 'Create your account to start competing.' : 'Verify your in-game identity with a screenshot.'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {step === 1 && (
              <>
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl><Input placeholder="John Doe" required className="h-12" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl><Input type="tel" placeholder="+91 12345 67890" required className="h-12" {...field} /></FormControl>
                       <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl><Input type="password" placeholder="Create a strong password" required className="h-12" {...field} /></FormControl>
                       <FormMessage />
                    </FormItem>
                  )}
                />
                 <Button
                    type="button"
                    onClick={handleNextStep}
                    className="w-full text-lg font-bold h-14 btn-glow"
                  >
                    Next
                  </Button>
              </>
            )}

            {step === 2 && (
              <>
                <Alert>
                  <ScanSearch className="h-4 w-4" />
                  <AlertTitle>Verify with Screenshot</AlertTitle>
                  <AlertDescription>
                    Upload a screenshot of your in-game profile to automatically fill in your UID and Level.
                  </AlertDescription>
                </Alert>
                
                <Input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                  accept="image/*"
                />

                <Button
                  type="button"
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full h-12"
                >
                  <Upload className="mr-2" />
                  {screenshotFile ? 'Change Screenshot' : 'Upload Screenshot'}
                </Button>

                {screenshotPreview && (
                  <div className="relative aspect-video w-full rounded-md border p-2">
                    <img src={screenshotPreview} alt="Screenshot preview" className="object-contain w-full h-full" />
                  </div>
                )}
                
                <Button
                  type="button"
                  onClick={handleVerifyScreenshot}
                  disabled={isVerifying || !screenshotFile}
                  className="w-full h-12 btn-glow"
                >
                  {isVerifying ? <Loader2 className="animate-spin" /> : 'Verify Screenshot'}
                </Button>

                <FormField
                  control={form.control}
                  name="gameUid"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Game UID (Auto-filled)</FormLabel>
                      <FormControl><Input placeholder="Auto-filled after verification" className="h-12" {...field} readOnly /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                 <FormField
                  control={form.control}
                  name="level"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Level (Auto-filled)</FormLabel>
                      <FormControl><Input type="number" placeholder="Auto-filled after verification" className="h-12" {...field} readOnly /></FormControl>
                       <FormMessage />
                    </FormItem>
                  )}
                />
                 <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Game Username (Editable)</FormLabel>
                      <FormControl><Input placeholder="Confirm or enter your username" className="h-12" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex gap-4">
                   <Button
                      type="button"
                      variant="outline"
                      onClick={() => setStep(1)}
                      className="w-full text-lg font-bold h-14"
                    >
                      Back
                    </Button>
                    <Button
                      type="submit"
                      className="w-full text-lg font-bold h-14 btn-glow"
                      disabled={isLoading}
                    >
                      {isLoading ? <Loader2 className="animate-spin" /> : 'Create Account'}
                    </Button>
                </div>
              </>
            )}
          </form>
        </Form>
        <div className="mt-6 text-center text-sm">
          Already a player?{" "}
          <Link
            href="/login"
            className="font-semibold text-accent underline-offset-4 hover:underline hover:text-accent/90"
          >
            Log in
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
