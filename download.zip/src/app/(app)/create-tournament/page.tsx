
'use client';

import { CreateTournamentForm } from "@/components/tournament/create/create-tournament-form";
import { AccessValidator } from "@/components/tournament/create/access-validator";
import { useAuthState } from "react-firebase-hooks/auth";
import { auth, db } from "@/lib/firebase";
import { useEffect, useState } from "react";
import { doc, getDoc, collection, query, where, getDocs, onSnapshot, Timestamp } from "firebase/firestore";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";


export default function CreateTournamentPage() {
  const [user, authLoading] = useAuthState(auth);
  const router = useRouter();
  const [userData, setUserData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [cooldownTimeLeft, setCooldownTimeLeft] = useState(0);

   useEffect(() => {
    if (authLoading) return;
    if (!user) {
      router.push('/login');
      return;
    }

    const fetchInitialData = async () => {
      // Fetch user data
      const userDocRef = doc(db, "users", user.uid);
      const userDoc = await getDoc(userDocRef);

      if (userDoc.exists()) {
        const data = userDoc.data();
        
        const tournamentsRef = collection(db, "tournaments");
        const q = query(tournamentsRef, where("hostId", "==", user.uid), where("status", "in", ["pending", "live"]));
        const activeTournamentSnapshot = await getDocs(q);
        
        const hasActiveTournament = !activeTournamentSnapshot.empty;
        
        const lastCreationTime = data.lastTournamentCreationTime as Timestamp | undefined;
        let cooldownLeft = 0;
        if (lastCreationTime) {
            const now = new Date().getTime();
            const lastCreation = lastCreationTime.toDate().getTime();
            // Cooldown is 15 minutes (15 * 60 * 1000 milliseconds)
            const cooldownPeriod = 15 * 60 * 1000;
            const timePassed = now - lastCreation;
            
            if (timePassed < cooldownPeriod) {
                cooldownLeft = (cooldownPeriod - timePassed) / (1000 * 60); // in minutes
            }
        }
        setCooldownTimeLeft(cooldownLeft);

        setUserData({
          ...data,
          isLoggedIn: !!user,
          hasGamingInfo: !!(data.gameUid && data.level && data.username),
          hasActiveTournament: hasActiveTournament,
        });
      }
      
      setLoading(false);
    };

    fetchInitialData();

  }, [user, authLoading, router]);

   useEffect(() => {
    if (cooldownTimeLeft > 0) {
      const interval = setInterval(() => {
        setCooldownTimeLeft((prev) => {
             const newTime = prev - (1 / 60); // subtract one second (in minutes)
             return Math.max(0, newTime);
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [cooldownTimeLeft]);


  if (loading || authLoading) {
    return (
      <div className="container px-4 sm:px-6 py-6 flex justify-center items-center">
        <Loader2 className="h-10 w-10 animate-spin text-primary"/>
      </div>
    );
  }

  return (
    <div className="container px-4 sm:px-6 py-6">
      <div className="flex justify-between items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold font-headline">Create Tournament</h1>
          <p className="text-muted-foreground">Host your own challenge in the arena</p>
        </div>
      </div>
      
      {userData && (
        <AccessValidator
          isLoggedIn={userData.isLoggedIn}
          hasGamingInfo={userData.hasGamingInfo}
          hasActiveTournament={userData.hasActiveTournament}
          cooldownTimeLeft={cooldownTimeLeft}
        >
          <CreateTournamentForm />
        </AccessValidator>
      )}
    </div>
  );
}
