
'use client';

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, Crown, ShieldCheck } from "lucide-react";

export default function HowItWorksPage() {
  return (
    <div className="container max-w-4xl px-4 sm:px-6 py-6 space-y-8">
       <div>
        <h1 className="text-3xl font-bold font-headline">How It Works</h1>
        <p className="text-muted-foreground">
          FirePlay का पूरा वर्कफ़्लो समझें।
        </p>
      </div>
      
      <Tabs defaultValue="player" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="player"><Users className="mr-2"/>Player</TabsTrigger>
          <TabsTrigger value="host"><Crown className="mr-2"/>Host</TabsTrigger>
          <TabsTrigger value="admin"><ShieldCheck className="mr-2"/>Admin</TabsTrigger>
        </TabsList>
        
        <TabsContent value="player" className="mt-6">
            <Card>
                <CardHeader>
                    <CardTitle>Player Workflow (खिलाड़ी)</CardTitle>
                    <CardDescription>Follow these steps to compete and win in tournaments.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Accordion type="single" collapsible className="w-full">
                        <AccordionItem value="item-1">
                            <AccordionTrigger>Step 1: Signup & Login</AccordionTrigger>
                            <AccordionContent>
                                <p className="font-semibold text-foreground">English:</p>
                                <p>Create an account using your phone number and password. During signup, upload a screenshot of your in-game profile. Our AI will automatically extract your Game UID, Level, and Username. After logging in, you will land in the tournament Lobby.</p>
                                <br/>
                                <p className="font-semibold text-foreground">हिन्दी:</p>
                                <p>अपने फोन नंबर और पासवर्ड से अकाउंट बनाएं। साइनअप के दौरान, अपने इन-गेम प्रोफाइल का स्क्रीनशॉट अपलोड करें। हमारा AI स्वचालित रूप से आपका गेम UID, लेवल और यूजरनेम निकाल लेगा। लॉग इन करने के बाद, आप टूर्नामेंट लॉबी में पहुंच जाएंगे।</p>
                            </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-2">
                            <AccordionTrigger>Step 2: Join a Tournament</AccordionTrigger>
                            <AccordionContent>
                               <p className="font-semibold text-foreground">English:</p>
                                <p>In the Lobby, you can see all available public tournaments. Click on any tournament to view its details like rules, entry fee, and prize pool. Click "Join Now" to enter. The entry fee will be deducted from your wallet, and you'll be added to the participants list.</p>
                                <br/>
                                <p className="font-semibold text-foreground">हिन्दी:</p>
                                <p>लॉबी में, आप सभी उपलब्ध सार्वजनिक टूर्नामेंट देख सकते हैं। किसी भी टूर्नामेंट पर क्लिक करके उसके नियम, प्रवेश शुल्क और पुरस्कार पूल जैसी जानकारी देखें। "Join Now" पर क्लिक करें। प्रवेश शुल्क आपके वॉलेट से काट लिया जाएगा, और आप प्रतिभागियों की सूची में शामिल हो जाएंगे।</p>
                            </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-3">
                            <AccordionTrigger>Step 3: Play the Match</AccordionTrigger>
                            <AccordionContent>
                                <p className="font-semibold text-foreground">English:</p>
                                <p>When the host starts the match, the In-Game Room ID and Password will become visible on the tournament detail page. Use these details to join the custom room inside the game.</p>
                                <br/>
                                <p className="font-semibold text-foreground">हिन्दी:</p>
                                <p>जब होस्ट मैच शुरू करेगा, तो इन-गेम रूम आईडी और पासवर्ड टूर्नामेंट विवरण पेज पर दिखाई देने लगेंगे। इन विवरणों का उपयोग करके गेम के अंदर कस्टम रूम में शामिल हों।</p>
                            </AccordionContent>
                        </AccordionItem>
                         <AccordionItem value="item-4">
                            <AccordionTrigger>Step 4: Submit Result & Claim Prize</AccordionTrigger>
                            <AccordionContent>
                                <p className="font-semibold text-foreground">English:</p>
                                <p>After winning the match, return to the tournament page on FirePlay. Click the "I'm a Winner" button and upload a screenshot of the final "BOOYAH!" screen. Our AI will cross-verify the players in your screenshot with the screenshots provided by the host. If everything matches, the prize money is instantly transferred to your wallet.</p>
                                <br/>
                                <p className="font-semibold text-foreground">हिन्दी:</p>
                                <p>मैच जीतने के बाद, FirePlay पर टूर्नामेंट पेज पर वापस आएं। "I'm a Winner" बटन पर क्लिक करें और अंतिम "BOOYAH!" स्क्रीन का स्क्रीनशॉट अपलोड करें। हमारा AI आपके स्क्रीनशॉट में मौजूद खिलाड़ियों का मिलान होस्ट द्वारा प्रदान किए गए स्क्रीनशॉट से करेगा। यदि सब कुछ मेल खाता है, तो पुरस्कार राशि तुरंत आपके वॉलेट में स्थानांतरित कर दी जाती है।</p>
                            </AccordionContent>
                        </AccordionItem>
                    </Accordion>
                </CardContent>
            </Card>
        </TabsContent>
        
        <TabsContent value="host" className="mt-6">
            <Card>
                <CardHeader>
                    <CardTitle>Host Workflow (टूर्नामेंट आयोजक)</CardTitle>
                    <CardDescription>Create and manage your own tournaments.</CardDescription>
                </CardHeader>
                 <CardContent>
                    <Accordion type="single" collapsible className="w-full">
                        <AccordionItem value="item-1">
                            <AccordionTrigger>Step 1: Create Tournament</AccordionTrigger>
                            <AccordionContent>
                                <p className="font-semibold text-foreground">English:</p>
                                <p>Click "Create Room" and follow the 4-step process to set up your tournament's game mode, entry fee, rules, and other settings.</p>
                                <br/>
                                <p className="font-semibold text-foreground">हिन्दी:</p>
                                <p>"Create Room" पर क्लिक करें और अपने टूर्नामेंट का गेम मोड, प्रवेश शुल्क, नियम और अन्य सेटिंग्स सेट करने के लिए 4-चरणीय प्रक्रिया का पालन करें।</p>
                            </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-2">
                            <AccordionTrigger>Step 2: Manage in Host Panel</AccordionTrigger>
                            <AccordionContent>
                               <p className="font-semibold text-foreground">English:</p>
                                <p>After creation, you get a dedicated Host Panel. Once the tournament is full, create the room in-game and enter the Room ID & Password in the panel. Then, upload a screenshot of the lobby showing all participants. After that, start the game and upload a screenshot of the first round (0 kills/0 damage) within 10 minutes.</p>
                                <br/>
                                <p className="font-semibold text-foreground">हिन्दी:</p>
                                <p>टूर्नामेंट बनाने के बाद, आपको एक समर्पित होस्ट पैनल मिलता है। टूर्नामेंट भर जाने पर, इन-गेम रूम बनाएं और पैनल में रूम आईडी और पासवर्ड दर्ज करें। फिर, सभी प्रतिभागियों को दिखाते हुए लॉबी का एक स्क्रीनशॉट अपलोड करें। उसके बाद, गेम शुरू करें और 10 मिनट के भीतर पहले राउंड (0 किल/0 डैमेज) का स्क्रीनशॉट अपलोड करें।</p>
                            </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-3">
                            <AccordionTrigger>Step 3: Wait for Winner</AccordionTrigger>
                            <AccordionContent>
                                <p className="font-semibold text-foreground">English:</p>
                                <p>Your job is done! The system will now wait for the winning player to submit their result screenshot for verification. You cannot manually declare a winner.</p>
                                <br/>
                                <p className="font-semibold text-foreground">हिन्दी:</p>
                                <p>आपका काम हो गया! सिस्टम अब विजेता खिलाड़ी द्वारा सत्यापन के लिए अपना परिणाम स्क्रीनशॉट जमा करने की प्रतीक्षा करेगा। आप मैन्युअल रूप से विजेता घोषित नहीं कर सकते।</p>
                            </AccordionContent>
                        </AccordionItem>
                    </Accordion>
                </CardContent>
            </Card>
        </TabsContent>
        
        <TabsContent value="admin" className="mt-6">
            <Card>
                <CardHeader>
                    <CardTitle>Admin Workflow (एडमिन)</CardTitle>
                    <CardDescription>Oversee and manage the entire platform.</CardDescription>
                </CardHeader>
                 <CardContent>
                    <Accordion type="single" collapsible className="w-full">
                        <AccordionItem value="item-1">
                            <AccordionTrigger>Role 1: User Verification</AccordionTrigger>
                            <AccordionContent>
                                <p className="font-semibold text-foreground">English:</p>
                                <p>When a new user sends their profile screenshot to the official WhatsApp number, the admin verifies it. In the Admin Panel, search for the user by phone number and generate a 6-digit verification code. Send this code back to the user on WhatsApp to complete their verification.</p>
                                <br/>
                                <p className="font-semibold text-foreground">हिन्दी:</p>
                                <p>जब कोई नया उपयोगकर्ता आधिकारिक व्हाट्सएप नंबर पर अपना प्रोफाइल स्क्रीनशॉट भेजता है, तो एडमिन उसे सत्यापित करता है। एडमिन पैनल में, फोन नंबर से उपयोगकर्ता को खोजें और 6 अंकों का सत्यापन कोड उत्पन्न करें। उपयोगकर्ता को उनका सत्यापन पूरा करने के लिए यह कोड व्हाट्सएप पर वापस भेजें।</p>
                            </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-2">
                            <AccordionTrigger>Role 2: Global Management</AccordionTrigger>
                            <AccordionContent>
                               <p className="font-semibold text-foreground">English:</p>
                                <p>The Admin has full control over the platform. They can view all users, manage tournaments, monitor transactions, and handle any disputes or fraudulent activity by banning users or cancelling tournaments.</p>
                                <br/>
                                <p className="font-semibold text-foreground">हिन्दी:</p>
                                <p>एडमिन का प्लेटफॉर्म पर पूरा नियंत्रण होता है। वे सभी उपयोगकर्ताओं को देख सकते हैं, टूर्नामेंट प्रबंधित कर सकते हैं, लेनदेन की निगरानी कर सकते हैं, और उपयोगकर्ताओं पर प्रतिबंध लगाकर या टूर्नामेंट रद्द करके किसी भी विवाद या धोखाधड़ी गतिविधि को संभाल सकते हैं।</p>
                            </AccordionContent>
                        </AccordionItem>
                    </Accordion>
                </CardContent>
            </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
