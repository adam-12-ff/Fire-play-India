
'use client';

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, Shield, Gamepad } from "lucide-react";

const storeItems = [
  {
    title: "Custom Gun Cards",
    description: "Create tournaments with your favorite weapon rules.",
    icon: <Gamepad className="w-8 h-8 text-primary" />,
    status: "Coming Soon",
    aiHint: "custom weapon card"
  },
  {
    title: "FirePlay Card Skins",
    description: "Customize your profile card with unique skins.",
    icon: <Shield className="w-8 h-8 text-primary" />,
    status: "Coming Soon",
    aiHint: "profile card skin"
  },
  {
    title: "Special Rule Unlocks",
    description: "Get access to exclusive tournament rule sets.",
    icon: <ShoppingCart className="w-8 h-8 text-primary" />,
    status: "Coming Soon",
    aiHint: "new rules"
  },
];

export default function StorePage() {
  return (
    <div className="container px-4 sm:px-6 py-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold font-headline">Store</h1>
        <p className="text-muted-foreground">Purchase special items to enhance your gaming experience.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {storeItems.map((item, index) => (
          <Card key={index} className="bg-card/50 border-border hover:border-primary/50 transition-all">
            <CardHeader>
              <div className="flex justify-between items-start">
                  <div className="flex items-center gap-4">
                    {item.icon}
                    <CardTitle>{item.title}</CardTitle>
                  </div>
                  <Badge variant="outline">{item.status}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{item.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
