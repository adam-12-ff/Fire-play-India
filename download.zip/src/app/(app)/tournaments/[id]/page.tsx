
'use client';

import { useEffect, useState, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { doc, getDoc, onSnapshot, runTransaction, arrayUnion, Timestamp, collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '@/lib/firebase';
import { useAuthState } from 'react-firebase-hooks/auth';
import type { TournamentData, Participant } from '@/lib/validators/tournament';
import { Loader2, Users, Shield, Trophy, Ticket, Swords, Calendar, Clock, Lock, Globe, Share2, Crown, Hash, KeyRound, LinkIcon, ShieldQuestion, Eye, Gamepad2, Heart, Skull, Repeat, Upload, ImageUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { Progress } from '@/components/ui/progress';
import { format } from 'date-fns';
import Image from 'next/image';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import Link from 'next/link';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { FirePlayCard } from '@/components/profile/fire-play-card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { verifyWinnerFromScreenshot } from '@/ai/flows/verify-winner-flow';


function InfoRow({ label, value, icon }: { label: string; value: React.ReactNode, icon: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between py-3">
      <div className="flex items-center gap-3">
        {icon}
        <p className="text-muted-foreground">{label}</p>
      </div>
      <div className="font-semibold text-right">{value}</div>
    </div>
  );
}

export default function TournamentDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const [user, userLoading] = useAuthState(auth);
  const [tournament, setTournament] = useState<TournamentData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isJoining, setIsJoining] = useState(false);
  const [userData, setUserData] = useState<any>(null);
  
  const resultFileInputRef = useRef<HTMLInputElement>(null);
  const [resultScreenshot, setResultScreenshot] = useState<File | null>(null);
  const [resultScreenshotPreview, setResultScreenshotPreview] = useState<string | null>(null);
  const [isSubmittingResult, setIsSubmittingResult] = useState(false);


  const tournamentId = Array.isArray(params.id) ? params.id[0] : params.id;
  
  useEffect(() => {
    if(!user && !userLoading) {
      router.push('/login');
    } else if (user) {
      const userDocRef = doc(db, 'users', user.uid);
      const unsubscribe = onSnapshot(userDocRef, (doc) => {
        setUserData(doc.data());
      });
      return () => unsubscribe();
    }
  }, [user, userLoading, router]);

  useEffect(() => {
    if (!tournamentId) return;

    const tournamentDocRef = doc(db, "tournaments", tournamentId as string);
    const unsubscribe = onSnapshot(tournamentDocRef, (doc) => {
      if (doc.exists()) {
        const data = doc.data() as any;
        // Convert Firestore Timestamps to JS Dates
        if (data.startTime && data.startTime instanceof Timestamp) {
            data.startTime = data.startTime.toDate();
        }
        setTournament(data);
      } else {
        toast({ variant: 'destructive', title: 'Tournament Not Found' });
        router.push('/');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [tournamentId, router, toast]);

  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    toast({
      title: 'Link Copied!',
      description: 'You can now share the tournament link with your friends.',
    });
  };

  const handleJoin = async () => {
    if (!user || !tournament || !userData) {
        toast({ variant: 'destructive', title: 'Error', description: 'You must be logged in and user data must be loaded to join.' });
        return;
    }
    
    if (userData.walletBalance < (tournament.entryFee + tournament.platformFee)) {
        toast({ variant: 'destructive', title: 'Insufficient Coins', description: 'Please add more coins to your wallet to join.' });
        router.push('/wallet');
        return;
    }

    setIsJoining(true);
    
    const tournamentRef = doc(db, "tournaments", tournamentId);
    const userRef = doc(db, "users", user.uid);

    try {
      await runTransaction(db, async (transaction) => {
        const tournamentDoc = await transaction.get(tournamentRef);
        const userDoc = await transaction.get(userRef);

        if (!tournamentDoc.exists()) throw new Error("Tournament not found.");
        if (!userDoc.exists()) throw new Error("User data not found.");

        const tournamentData = tournamentDoc.data();
        const currentParticipants = tournamentData.participants || [];

        if (currentParticipants.length >= tournamentData.maxPlayers) {
            throw new Error("This tournament is already full.");
        }
        
        if (currentParticipants.some((p: any) => p === user.uid)) {
            throw new Error("You have already joined this tournament.");
        }

        const fee = tournament.entryFee + tournament.platformFee;
        const newBalance = userDoc.data().walletBalance - fee;
        transaction.update(userRef, { walletBalance: newBalance });
        
        // This is the new participant object we store in the `participants_details` map
        const newParticipantDetails: Participant = {
            uid: user.uid,
            name: userData.name || user.displayName || 'Anonymous',
            username: userData.username || 'Not Set',
            gameUid: userData.gameUid || 'Not Set',
            level: userData.level || 'N/A',
            rank: userData.rank || 'Unranked',
            fireplayId: userData.fireplayId || '',
            isVerified: userData.isVerified || false,
        };
        
        // We add the UID to the participants array for easy querying
        // And we add the detailed object to the new map field
        transaction.update(tournamentRef, {
            participants: arrayUnion(user.uid),
            [`participants_details.${user.uid}`]: newParticipantDetails
        });
        
        // Log the transaction
        const userTransactionsRef = collection(db, 'users', user.uid, 'transactions');
        transaction.set(doc(userTransactionsRef), {
            type: 'Entry Fee',
            amount: -fee,
            date: serverTimestamp(),
            status: 'Success',
            tournamentId: tournamentId,
            transactionType: 'debit'
        });
      });

      toast({ title: 'Joined Successfully!', description: `Entry fee of ${tournament.entryFee + tournament.platformFee} coins has been deducted.` });
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Failed to Join',
        description: error.message || 'Could not join the tournament.',
      });
    } finally {
      setIsJoining(false);
    }
  };
  
  const handleResultFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setResultScreenshot(file);
        setResultScreenshotPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const fileToDataUri = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (event) => {
            resolve(event.target?.result as string);
        };
        reader.onerror = (error) => {
            reject(error);
        };
        reader.readAsDataURL(file);
    });
  };

  const handleResultSubmit = async () => {
    if (!resultScreenshot || !user || !userData || !tournament || !tournament.lobbyScreenshotUrl || !tournament.startScreenshotUrl) {
      toast({ variant: 'destructive', title: 'Error', description: 'Missing required data or previous screenshots to submit result.' });
      return;
    }
    setIsSubmittingResult(true);

    try {
        const resultScreenshotDataUri = await fileToDataUri(resultScreenshot);
        
        const lobbyScreenshotDataUri = tournament.lobbyScreenshotUrl;
        const startScreenshotDataUri = tournament.startScreenshotUrl;

        const verificationResult = await verifyWinnerFromScreenshot({
            resultScreenshotDataUri,
            lobbyScreenshotDataUri,
            startScreenshotDataUri,
            expectedWinnerName: userData.username,
        });

        if (!verificationResult.isVerified) {
            toast({
                variant: 'destructive',
                title: 'Verification Failed',
                description: verificationResult.reason || "Could not verify you as the winner from the screenshot."
            });
            setIsSubmittingResult(false);
            return;
        }

        // If verified, run the transaction to award the prize
        const tournamentRef = doc(db, "tournaments", tournamentId);
        const winnerUserRef = doc(db, "users", user.uid);

        await runTransaction(db, async (transaction) => {
            const tournamentDoc = await transaction.get(tournamentRef);
            const winnerDoc = await transaction.get(winnerUserRef);

            if (!tournamentDoc.exists() || !winnerDoc.exists()) throw new Error("Tournament or winner data not found.");

            const currentTournamentData = tournamentDoc.data();
            if (currentTournamentData.status !== 'live') throw new Error("This tournament is not live or has already ended.");

            const winnerData = winnerDoc.data();
            const prize = currentTournamentData.prizePool;
            const newBalance = winnerData.walletBalance + prize;

            // 1. Update winner's wallet
            transaction.update(winnerUserRef, { walletBalance: newBalance });

            // 2. Update tournament status and winner info
            transaction.update(tournamentRef, {
                status: 'completed',
                winner: {
                    uid: user.uid,
                    name: winnerData.name || winnerData.username,
                },
                resultScreenshotUrl: "dummy_url_for_now", // Here you would upload to storage and save URL
            });

            // 3. Log the prize transaction for winner
            const winnerTransactionsRef = collection(db, 'users', user.uid, 'transactions');
            transaction.set(doc(winnerTransactionsRef), {
                type: 'Prize Won',
                amount: prize,
                date: serverTimestamp(),
                status: 'Success',
                tournamentId: tournamentId,
                tournamentName: currentTournamentData.title,
                transactionType: 'credit'
            });
        });

        toast({ title: 'Result Verified!', description: `Congratulations! ${tournament.prizePool} coins have been added to your wallet.` });
        setResultScreenshot(null);
        setResultScreenshotPreview(null);
    } catch (error: any) {
        toast({ variant: 'destructive', title: 'Result Submission Failed', description: error.message });
    } finally {
        setIsSubmittingResult(false);
    }
};

  if (loading || userLoading) {
    return (
      <div className="container flex items-center justify-center py-6">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  if (!tournament) {
    return null; // or a not found component
  }
  
  const participantsCount = tournament.participants?.length || 0;
  const participantDetails: Participant[] = tournament.participants_details ? Object.values(tournament.participants_details) : [];

  const isHost = tournament.hostId === user?.uid;
  const isParticipant = tournament.participants?.includes(user?.uid || '');
  const isFull = participantsCount >= tournament.maxPlayers;
  const totalEntryFee = tournament.entryFee + tournament.platformFee;
  const isCompleted = tournament.status === 'completed';

  return (
    <div className="container max-w-4xl px-4 sm:px-6 py-6">
        <div className="relative w-full h-48 md:h-64 rounded-xl overflow-hidden mb-6">
            <Image
                src="https://placehold.co/800x400.png"
                alt={tournament.title}
                data-ai-hint="battle royale intense"
                fill
                className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />
            <div className="absolute bottom-4 left-4 md:bottom-6 md:left-6">
                <h1 className="text-3xl md:text-4xl font-bold font-headline text-white">{tournament.title}</h1>
                <div className="flex gap-2 mt-2">
                    <Badge variant="secondary" className="bg-black/50 text-white">{tournament.gameMode}</Badge>
                    <Badge variant="secondary" className="bg-black/50 text-white">{tournament.matchType}</Badge>
                    {isHost && <Badge variant="default" className="bg-primary/80 text-white">You are the host</Badge>}
                </div>
            </div>
             <Button onClick={handleShare} variant="outline" size="icon" className="absolute top-4 right-4 bg-black/30 hover:bg-black/50 border-white/30 hover:border-white/50 text-white">
                <Share2 className="h-5 w-5"/>
                <span className="sr-only">Share Tournament</span>
            </Button>
        </div>

        {isHost && !isCompleted && (
            <div className="mb-6">
                 <Button asChild className="w-full btn-glow">
                    <Link href={`/tournaments/${tournamentId}/manage`}>
                        <Crown className="mr-2 h-4 w-4" /> Manage Tournament
                    </Link>
                </Button>
            </div>
        )}

        {isCompleted && tournament.winner && (
            <Alert className="mb-6 border-green-500/30 bg-green-500/10 text-green-400">
                <Trophy className="h-4 w-4 text-current" />
                <AlertTitle className="text-current">Tournament Completed!</AlertTitle>
                <AlertDescription>
                    The winner of this tournament is <span className="font-bold">{tournament.winner.name}</span>.
                </AlertDescription>
            </Alert>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-6">
                 <Card>
                    <CardHeader>
                        <CardTitle>Tournament Details</CardTitle>
                        <CardDescription>All the important info about this tournament.</CardDescription>
                    </CardHeader>
                    <CardContent className="divide-y divide-border">
                        <InfoRow label="Tournament ID" icon={<Lock className="w-5 h-5 text-primary" />} value={<span className="font-mono">{tournament.id}</span>} />
                        <InfoRow label="Total Entry" icon={<Ticket className="w-5 h-5 text-primary" />} value={`${totalEntryFee} Coins (${tournament.entryFee} + ${tournament.platformFee} Fee)`} />
                        <InfoRow label="Prize Pool" icon={<Trophy className="w-5 h-5 text-primary" />} value={`${tournament.prizePool} Coins`} />
                        <InfoRow label="Start Time" icon={<Clock className="w-5 h-5 text-primary" />} value={format(tournament.startTime, "PPpp")} />
                        <InfoRow label="Visibility" icon={<Globe className="w-5 h-5 text-primary" />} value={<span className="capitalize">{tournament.visibility}</span>} />
                    </CardContent>
                 </Card>

                 {tournament.status === 'live' && (tournament.roomId || tournament.roomLink) && isParticipant && (
                     <Card className="border-accent">
                        <CardHeader>
                            <CardTitle>In-Game Room Details</CardTitle>
                            <CardDescription>Use these details to join the room inside the game.</CardDescription>
                        </CardHeader>
                        <CardContent>
                          {tournament.roomLink ? (
                             <Button asChild className="w-full btn-glow-accent bg-accent hover:bg-accent/90">
                                <a href={tournament.roomLink} target="_blank" rel="noopener noreferrer">
                                    <LinkIcon className="mr-2 h-5 w-5" />
                                    Join via Link
                                </a>
                              </Button>
                          ) : (
                            <div className='divide-y divide-border'>
                              <InfoRow label="Room ID" icon={<Hash className="w-5 h-5 text-accent" />} value={<span className="font-mono text-accent">{tournament.roomId}</span>} />
                              <InfoRow label="Password" icon={<KeyRound className="w-5 h-5 text-accent" />} value={<span className="font-mono text-accent">{tournament.roomPassword}</span>} />
                            </div>
                          )}
                        </CardContent>
                     </Card>
                 )}

                 <Card>
                    <CardHeader>
                        <CardTitle>Rules & Settings</CardTitle>
                    </CardHeader>
                    <CardContent className="divide-y divide-border">
                        <InfoRow label="Preset Mode" icon={<Gamepad2 className="w-5 h-5 text-primary" />} value={<Badge variant="outline">{tournament.presetMode}</Badge>} />
                        <InfoRow label="Headshot Only" icon={<Skull className="w-5 h-5 text-primary" />} value={<Badge variant={tournament.rules.headshotOnly ? "default" : "secondary"}>{tournament.rules.headshotOnly ? "Yes" : "No"}</Badge>} />
                        <InfoRow label="Unlimited Ammo" icon={<Repeat className="w-5 h-5 text-primary" />} value={<Badge variant={tournament.rules.unlimitedAmmo ? "default" : "secondary"}>{tournament.rules.unlimitedAmmo ? "Yes" : "No"}</Badge>} />
                        <InfoRow label="Gun Attributes" icon={<Swords className="w-5 h-5 text-primary" />} value={<Badge variant={tournament.rules.gunAttributes ? "default" : "secondary"}>{tournament.rules.gunAttributes ? "Yes" : "No"}</Badge>} />
                         <InfoRow label="Grenade Throw" icon={<Swords className="w-5 h-5 text-primary" />} value={<Badge variant={tournament.rules.grenadeThrow ? "default" : "secondary"}>{tournament.rules.grenadeThrow ? "Yes" : "No"}</Badge>} />
                        {tournament.matchType !== 'Solo' && <InfoRow label="Revive" icon={<Heart className="w-5 h-5 text-primary" />} value={<Badge variant={tournament.rules.revive ? "default" : "secondary"}>{tournament.rules.revive ? "Yes" : "No"}</Badge>} />}
                        <InfoRow label="Gun Card Boost" icon={<Swords className="w-5 h-5 text-primary" />} value={<Badge variant={tournament.gunCardSupport ? "default" : "secondary"}>{tournament.gunCardSupport ? "Yes" : "No"}</Badge>} />
                    </CardContent>
                 </Card>
            </div>
            
            <div className="space-y-6">
                <Card className="bg-card/70 border-primary/20">
                    <CardHeader>
                        <CardTitle>Join the Arena</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <div className="flex justify-between items-center mb-1 text-sm text-muted-foreground">
                                <div className="flex items-center gap-1"><Users className="h-4 w-4" /> Participants</div>
                                <span>{participantsCount} / {tournament.maxPlayers}</span>
                            </div>
                            <Progress value={(participantsCount / tournament.maxPlayers) * 100} className="h-2 [&>div]:bg-primary" />
                        </div>
                        {isParticipant ? (
                             <Alert className="border-green-500/30 bg-green-500/10 text-green-400">
                                <AlertTitle>You're in!</AlertTitle>
                                <AlertDescription>You have successfully joined this tournament. Good luck!</AlertDescription>
                            </Alert>
                        ) : isFull || isCompleted ? (
                             <Alert variant="destructive">
                                <AlertTitle>{isCompleted ? "Tournament Ended" : "Tournament Full"}</AlertTitle>
                                <AlertDescription>{isCompleted ? "This tournament is now complete." : "The maximum number of participants has been reached."}</AlertDescription>
                            </Alert>
                        ) : (
                             <Button onClick={handleJoin} disabled={isJoining} className="w-full h-12 text-lg font-bold btn-glow-accent bg-accent hover:bg-accent/90">
                                {isJoining ? <Loader2 className="animate-spin" /> : 'Join Now'}
                            </Button>
                        )}
                       {isParticipant && tournament.status === 'live' && (
                           <Dialog>
                               <DialogTrigger asChild>
                                   <Button variant="outline" className="w-full">
                                       <Trophy className="mr-2"/> I'm a Winner (Upload Result)
                                   </Button>
                               </DialogTrigger>
                               <DialogContent>
                                   <DialogHeader>
                                       <DialogTitle>Submit Result Screenshot</DialogTitle>
                                       <DialogDescription>
                                           Upload the final result screenshot showing the winning screen. Our AI will verify it.
                                       </DialogDescription>
                                   </DialogHeader>
                                   <div className="py-4 space-y-4">
                                       <Input
                                           type="file"
                                           ref={resultFileInputRef}
                                           onChange={handleResultFileChange}
                                           className="hidden"
                                           accept="image/*"
                                       />
                                       <Button
                                           variant="outline"
                                           size="lg"
                                           className="h-24 w-full border-dashed"
                                           onClick={() => resultFileInputRef.current?.click()}
                                       >
                                           <ImageUp className="h-8 w-8 mr-4"/>
                                           {resultScreenshot ? 'Change Screenshot' : 'Click to upload Result Screenshot'}
                                       </Button>
                                       {resultScreenshotPreview && (
                                           <div className="relative w-full aspect-video rounded-md border p-1 bg-secondary/20">
                                               <Image
                                                   src={resultScreenshotPreview}
                                                   alt="Result screenshot preview"
                                                   fill
                                                   className="object-contain"
                                               />
                                           </div>
                                       )}
                                   </div>
                                   <DialogFooter>
                                       <Button onClick={handleResultSubmit} disabled={isSubmittingResult || !resultScreenshot} className="w-full btn-glow">
                                           {isSubmittingResult ? <Loader2 className="animate-spin"/> : 'Submit for Verification'}
                                       </Button>
                                   </DialogFooter>
                               </DialogContent>
                           </Dialog>
                       )}
                       {isParticipant && (
                           <Button variant="destructive" className="w-full" disabled>
                                <ShieldQuestion className="mr-2"/> Report an Issue (Coming Soon)
                           </Button>
                       )}
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader>
                        <CardTitle>Participants</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {participantDetails.length > 0 ? (
                            <ul className="space-y-3 max-h-60 overflow-y-auto">
                                {participantDetails.map(p => (
                                    <li key={p.uid} className="flex items-center justify-between gap-2 p-2 rounded-md bg-secondary/30">
                                        <div className='flex items-center gap-3'>
                                            <Avatar className="h-8 w-8">
                                                <AvatarImage src={`https://source.boringavatars.com/beam/120/${p.uid}?colors=A020F0,7CFC00,FFFFFF,1f2128,262931`} alt={p.name} />
                                                <AvatarFallback>{p.name.charAt(0)}</AvatarFallback>
                                            </Avatar>
                                            <div>
                                                <p className="text-sm font-semibold">{p.username}</p>
                                                <p className="text-xs font-mono text-muted-foreground">{p.gameUid}</p>
                                            </div>
                                        </div>
                                        <Dialog>
                                            <DialogTrigger asChild>
                                                <Button size="icon" variant="ghost" className="h-8 w-8">
                                                    <Eye className="h-4 w-4" />
                                                </Button>
                                            </DialogTrigger>
                                            <DialogContent>
                                                <DialogHeader>
                                                    <DialogTitle className='sr-only'>{p.name}'s FirePlay Card</DialogTitle>
                                                    <DialogDescription className='sr-only'>Viewing the FirePlay Card for player {p.name}.</DialogDescription>
                                                </DialogHeader>
                                                <FirePlayCard userData={p} showVerificationButton={false} />
                                            </DialogContent>
                                        </Dialog>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-sm text-muted-foreground text-center py-4">Be the first one to join!</p>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    </div>
  );
}
