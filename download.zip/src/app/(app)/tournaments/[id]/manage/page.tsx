
'use client';

import { useEffect, useState, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { doc, getDoc, onSnapshot, updateDoc, runTransaction, collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '@/lib/firebase';
import { useAuthState } from 'react-firebase-hooks/auth';
import { Loader2, ShieldAlert, KeyRound, Hash, Upload, Trophy, ListOrdered, LinkIcon, ShieldQuestion, MessageCircle, UserCheck, ArrowRight, ImageUp, Gamepad2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { type TournamentData, type Participant } from '@/lib/validators/tournament';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Progress } from '@/components/ui/progress';
import Image from 'next/image';

type ManagementStep = 'details' | 'uploadRoom' | 'uploadStart' | 'results' | 'completed';

// Helper to convert file to Base64 Data URI
const fileToDataUri = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        resolve(event.target.result as string);
      } else {
        reject(new Error("Failed to read file."));
      }
    };
    reader.onerror = (error) => {
      reject(error);
    };
    reader.readAsDataURL(file);
  });
};


export default function ManageTournamentPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const [user, userLoading] = useAuthState(auth);

  const [tournament, setTournament] = useState<TournamentData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [roomId, setRoomId] = useState('');
  const [roomPassword, setRoomPassword] = useState('');
  const [roomLink, setRoomLink] = useState('');

  const [managementStep, setManagementStep] = useState<ManagementStep>('details');
  
  const lobbyFileInputRef = useRef<HTMLInputElement>(null);
  const startFileInputRef = useRef<HTMLInputElement>(null);

  const [lobbyScreenshotFile, setLobbyScreenshotFile] = useState<File | null>(null);
  const [lobbyScreenshotPreview, setLobbyScreenshotPreview] = useState<string | null>(null);
  const [startScreenshotFile, setStartScreenshotFile] = useState<File | null>(null);
  const [startScreenshotPreview, setStartScreenshotPreview] = useState<string | null>(null);

  const tournamentId = Array.isArray(params.id) ? params.id[0] : params.id;

  useEffect(() => {
    if (userLoading) return;
    if (!user) {
      router.push('/login');
      return;
    }

    const tournamentDocRef = doc(db, 'tournaments', tournamentId as string);
    const unsubscribe = onSnapshot(tournamentDocRef, (doc) => {
      if (doc.exists()) {
        const data = doc.data() as TournamentData;
        if (data.hostId !== user.uid) {
          toast({ variant: 'destructive', title: 'Access Denied', description: 'You are not the host of this tournament.' });
          router.push(`/tournaments/${tournamentId}`);
        } else {
          setTournament(data);
          setRoomId(data.roomId || '');
          setRoomPassword(data.roomPassword || '');
          setRoomLink(data.roomLink || '');
          
          if (data.status === 'completed' || data.status === 'cancelled') {
            setManagementStep('completed');
          } else if (data.status === 'live') {
             if(data.startScreenshotUrl) {
                setManagementStep('results');
             } else {
                setManagementStep('uploadStart');
             }
          } else if(data.lobbyScreenshotUrl) {
            setManagementStep('uploadStart');
          } else if(data.roomId) {
            setManagementStep('uploadRoom');
          } else {
            setManagementStep('details');
          }

        }
      } else {
        toast({ variant: 'destructive', title: 'Tournament Not Found' });
        router.push('/');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user, userLoading, tournamentId, router, toast]);

  const handleUpdateRoomDetails = async () => {
    if(roomId.length < 7 || roomId.length > 9) {
      toast({ variant: 'destructive', title: 'Invalid Room ID', description: 'Room ID must be between 7-9 characters.' });
      return;
    }
    if(roomPassword.length > 10) {
      toast({ variant: 'destructive', title: 'Invalid Password', description: 'Password cannot be more than 10 characters.' });
      return;
    }

    setIsUpdating(true);
    try {
      const tournamentDocRef = doc(db, 'tournaments', tournamentId as string);
      await updateDoc(tournamentDocRef, {
        roomId: roomId,
        roomPassword: roomPassword,
        roomLink: roomLink,
      });
      toast({ title: 'Room Details Saved!', description: 'Now, please upload the room lobby screenshot.' });
      setManagementStep('uploadRoom');
    } catch (error) {
      toast({ variant: 'destructive', title: 'Update Failed', description: 'Could not update room details.' });
    } finally {
      setIsUpdating(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'lobby' | 'start') => {
    const file = e.target.files?.[0];
    if (file) {
      if (type === 'lobby') {
        setLobbyScreenshotFile(file);
        const reader = new FileReader();
        reader.onloadend = () => setLobbyScreenshotPreview(reader.result as string);
        reader.readAsDataURL(file);
      } else {
        setStartScreenshotFile(file);
        const reader = new FileReader();
        reader.onloadend = () => setStartScreenshotPreview(reader.result as string);
        reader.readAsDataURL(file);
      }
    }
  };

  const handleVerifyAndStart = async () => {
    if (!lobbyScreenshotFile) return;
    setIsUpdating(true);
    try {
      const lobbyScreenshotUrl = await fileToDataUri(lobbyScreenshotFile);
      const tournamentDocRef = doc(db, 'tournaments', tournamentId as string);
      
      // In a real app, you might upload to a storage service instead of storing a large Data URI.
      // For now, we store it directly for the OCR flow to access.
      await updateDoc(tournamentDocRef, { 
        status: 'live',
        lobbyScreenshotUrl: lobbyScreenshotUrl 
      });

      toast({ title: 'Tournament is Live!', description: 'Players can now see room details. Upload start-game screenshot within 10 mins!' });
      setManagementStep('uploadStart');
    } catch (error) {
      toast({ variant: 'destructive', title: 'Failed to Start', description: 'Could not start the tournament.' });
    } finally {
      setIsUpdating(false);
    }
  };

  const handleUploadStartScreenshot = async () => {
    if (!startScreenshotFile) return;
    setIsUpdating(true);
    try {
      const startScreenshotUrl = await fileToDataUri(startScreenshotFile);
      const tournamentDocRef = doc(db, 'tournaments', tournamentId as string);
      
      await updateDoc(tournamentDocRef, { 
        startScreenshotUrl: startScreenshotUrl 
      });

      toast({ title: 'Start Screenshot Verified!', description: 'The match is officially underway. Awaiting final results.'});
      setManagementStep('results');
    } catch (error) {
      toast({ variant: 'destructive', title: 'Upload Failed', description: 'Could not verify start-game screenshot.' });
    } finally {
      setIsUpdating(false);
    }
  };
  
  if (loading || userLoading) {
    return (
      <div className="container flex items-center justify-center py-6">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  if (!tournament) {
    return null;
  }
  
  const participantsCount = tournament.participants?.length || 0;
  const participantDetails: Participant[] = tournament.participants_details ? Object.values(tournament.participants_details) : [];
  const isFull = participantsCount >= tournament.maxPlayers;
  const canDeclareWinner = tournament.status === 'live';


  const renderContent = () => {
    switch(managementStep) {
        case 'details':
            return (
                <Card>
                  <CardHeader>
                    <CardTitle>Step 1: Room Management</CardTitle>
                    <CardDescription>Enter the in-game Room ID and Password for your participants.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                     {!isFull && tournament.status === 'pending' && (
                         <Alert variant="destructive">
                            <AlertTitle>Waiting for Players</AlertTitle>
                            <AlertDescription>The tournament is not full yet. Please wait for all participants to join before sharing room details.</AlertDescription>
                        </Alert>
                     )}
                    <div className="space-y-2">
                        <Label htmlFor="roomId">In-Game Room ID (7-9 characters)</Label>
                        <div className="relative">
                            <Hash className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                            <Input id="roomId" placeholder="Enter Room ID" value={roomId} onChange={(e) => setRoomId(e.target.value)} className="pl-10 h-12" maxLength={9}/>
                        </div>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="roomPassword">In-Game Room Password (max 10 chars)</Label>
                        <div className="relative">
                             <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                            <Input id="roomPassword" placeholder="Enter Password" value={roomPassword} onChange={(e) => setRoomPassword(e.target.value)} className="pl-10 h-12" maxLength={10}/>
                        </div>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="roomLink">Room Share Link (Optional)</Label>
                        <div className="relative">
                             <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                            <Input id="roomLink" placeholder="Paste official room link here" value={roomLink} onChange={(e) => setRoomLink(e.target.value)} className="pl-10 h-12" />
                        </div>
                    </div>
                    <Button onClick={handleUpdateRoomDetails} disabled={isUpdating || !isFull} className="w-full btn-glow">
                        {isUpdating ? <Loader2 className="animate-spin" /> : 'Save & Continue'}
                        <ArrowRight/>
                    </Button>
                  </CardContent>
                </Card>
            );
        case 'uploadRoom':
             return (
                <Card>
                  <CardHeader>
                    <CardTitle>Step 2: Upload Lobby Screenshot</CardTitle>
                    <CardDescription>Upload a screenshot of the game lobby showing all participants. Our AI will verify it before starting the match.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4 text-center">
                    <Input 
                        type="file"
                        ref={lobbyFileInputRef}
                        onChange={(e) => handleFileChange(e, 'lobby')}
                        className="hidden"
                        accept="image/*"
                    />
                    <Button 
                        variant="outline" 
                        size="lg" 
                        className="h-24 w-full border-dashed"
                        onClick={() => lobbyFileInputRef.current?.click()}
                    >
                        <ImageUp className="h-8 w-8 mr-4"/>
                        {lobbyScreenshotFile ? 'Change Screenshot' : 'Click to upload Lobby Screenshot'}
                    </Button>
                     {lobbyScreenshotPreview && (
                      <div className="relative w-full aspect-video rounded-md border p-1 bg-secondary/20">
                        <Image
                          src={lobbyScreenshotPreview}
                          alt="Room screenshot preview"
                          fill
                          className="object-contain"
                        />
                      </div>
                    )}
                    <p className="text-muted-foreground text-sm">After verification, the game will be started.</p>
                     <Button onClick={handleVerifyAndStart} disabled={isUpdating || !lobbyScreenshotFile} className="w-full btn-glow">
                        {isUpdating ? <Loader2 className="animate-spin" /> : <Gamepad2 />}
                        Verify & Start Game
                    </Button>
                  </CardContent>
                </Card>
            );
        case 'uploadStart':
            return (
                 <Card>
                  <CardHeader>
                    <CardTitle>Step 3: Upload Start-Game Screenshot</CardTitle>
                    <CardDescription>Upload a screenshot of the first round showing all players with 0 kills/damage. This must be done within 10 minutes of starting.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4 text-center">
                    <Input 
                        type="file"
                        ref={startFileInputRef}
                        onChange={(e) => handleFileChange(e, 'start')}
                        className="hidden"
                        accept="image/*"
                    />
                     <Button 
                        variant="outline" 
                        size="lg" 
                        className="h-24 w-full border-dashed"
                        onClick={() => startFileInputRef.current?.click()}
                    >
                        <ImageUp className="h-8 w-8 mr-4"/>
                        {startScreenshotFile ? 'Change Start Screenshot' : 'Upload 0 Kill/Damage Screenshot'}
                    </Button>
                    {startScreenshotPreview && (
                      <div className="relative w-full aspect-video rounded-md border p-1 bg-secondary/20">
                        <Image src={startScreenshotPreview} alt="Start game screenshot preview" fill className="object-contain" />
                      </div>
                    )}
                    <Button onClick={handleUploadStartScreenshot} disabled={isUpdating || !startScreenshotFile} className="w-full btn-glow">
                        {isUpdating ? <Loader2 className="animate-spin" /> : 'Confirm Start'}
                    </Button>
                  </CardContent>
                </Card>
            )
        case 'results':
            return (
                 <Card>
                    <CardHeader>
                        <CardTitle>Step 4: Awaiting Results</CardTitle>
                        <CardDescription>The game is officially live. The winning player must now upload the result screenshot from the tournament detail page to claim their prize.</CardDescription>
                    </CardHeader>
                    <CardContent className="text-center py-8">
                       <div className="flex justify-center items-center">
                         <Loader2 className="h-8 w-8 animate-spin text-primary" />
                       </div>
                       <p className="mt-4 text-muted-foreground">Waiting for winner to submit result screenshot...</p>
                    </CardContent>
                </Card>
            )
        case 'completed':
            return (
                <Alert className="border-green-500/30 bg-green-500/10 text-green-400">
                    <Trophy className="h-4 w-4 text-current" />
                    <AlertTitle className="text-current">Tournament Completed</AlertTitle>
                    <AlertDescription>
                        The winner is <span className="font-bold">{tournament.winner?.name || 'N/A'}</span>. The prize has been sent.
                    </AlertDescription>
                </Alert>
            );

    }
  }


  return (
    <div className="container max-w-4xl px-4 sm:px-6 py-6 space-y-6">
       <div>
        <h1 className="text-3xl font-bold font-headline">Host Panel</h1>
        <p className="text-muted-foreground">Manage your tournament: "{tournament.title}"</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className='md:col-span-2 space-y-6'>
           <div className='flex items-center gap-4'>
                <div className='text-center'>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${managementStep === 'details' ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}>1</div>
                    <p className='text-xs mt-1'>Details</p>
                </div>
                <Separator className={`flex-1 ${managementStep !== 'details' ? 'bg-primary' : ''}`}/>
                 <div className='text-center'>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${managementStep === 'uploadRoom' || managementStep === 'uploadStart' ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}>2</div>
                    <p className='text-xs mt-1'>Verify</p>
                </div>
                 <Separator className={`flex-1 ${managementStep === 'results' ? 'bg-primary' : ''}`}/>
                <div className='text-center'>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${managementStep === 'results' ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}>3</div>
                    <p className='text-xs mt-1'>Results</p>
                </div>
            </div>
            {renderContent()}
        </div>
        
         <Card className="md:col-span-1">
            <CardHeader>
                <CardTitle className="flex items-center gap-2"><ListOrdered/> Participant List</CardTitle>
                 <CardDescription>Total Participants: {participantsCount} / {tournament.maxPlayers}</CardDescription>
            </CardHeader>
            <CardContent>
                {participantDetails.length > 0 ? (
                    <ul className="space-y-2 max-h-96 overflow-y-auto">
                        {participantDetails.map(p => (
                            <li key={p.uid} className="text-sm font-medium text-muted-foreground bg-secondary/20 p-2 rounded-md">{p.name}</li>
                        ))}
                    </ul>
                ) : (
                    <p className="text-sm text-muted-foreground text-center py-4">No participants have joined yet.</p>
                )}
            </CardContent>
        </Card>
      </div>
    </div>
  );
}
