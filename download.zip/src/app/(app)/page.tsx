
'use client';

import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TournamentCard, type TournamentCardProps } from "@/components/tournament/tournament-card";
// import { AISuggestions } from "@/components/dashboard/ai-suggestions";
import { PlusCircle, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import Link from "next/link";
import { useEffect, useState } from "react";
import { collection, onSnapshot, query, where, Timestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TournamentCardSkeleton } from "@/components/dashboard/tournament-card-skeleton";

export default function DashboardPage() {
  const [tournaments, setTournaments] = useState<TournamentCardProps[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Only fetch public tournaments that are in 'pending' state
    const q = query(
      collection(db, "tournaments"), 
      where("visibility", "==", "public"),
      where("status", "==", "pending")
    );
    
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const tournamentsData: TournamentCardProps[] = [];
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        const participantsCount = Array.isArray(data.participants) ? data.participants.length : 0;
        
        // Exclude full tournaments on the client-side as a fallback
        if (participantsCount < data.maxPlayers) {
            tournamentsData.push({
              id: doc.id,
              name: data.title,
              game: data.gameMode,
              mode: data.matchType,
              prize: data.prizePool,
              entryFee: data.entryFee,
              participants: participantsCount,
              maxParticipants: data.maxPlayers,
              status: 'Open',
              imageUrl: 'https://placehold.co/600x400.png',
              aiHint: 'battle royale intense',
            });
        }
      });
      setTournaments(tournamentsData);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);
  
  const renderTournamentGrid = (filteredTournaments: TournamentCardProps[]) => {
     if (loading) {
      return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <TournamentCardSkeleton key={i} />)}
        </div>
      );
    }
    
    if (filteredTournaments.length === 0) {
      return <div className="text-center py-12 text-muted-foreground">कोई उपलब्ध टूर्नामेंट नहीं मिला।</div>
    }

    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredTournaments.map(t => <TournamentCard key={t.id} tournament={t} />)}
      </div>
    )
  }

  return (
    <div className="container px-4 sm:px-6 py-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold font-headline">Lobby</h1>
          <p className="text-muted-foreground">Find your next challenge</p>
        </div>
        <Button size="lg" className="w-full sm:w-auto font-bold btn-glow" asChild>
          <Link href="/create-tournament">
            <PlusCircle className="mr-2 h-5 w-5" />
            Create Room
          </Link>
        </Button>
      </div>

      <Card className="mb-8 bg-gradient-to-r from-primary/10 to-background border-primary/20">
        <CardHeader>
          <CardTitle className="font-headline text-2xl text-primary">Welcome to FirePlay Arena!</CardTitle>
          <CardDescription>आपका अपना गेमिंग अखाड़ा।</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-foreground/90">
            यहाँ आप अपने दोस्तों के साथ कस्टम टूर्नामेंट बना सकते हैं, उन्हें चैलेंज कर सकते हैं, और अपनी गेमिंग स्किल्स दिखाकर ढेर सारे इनाम जीत सकते हैं। अपना खुद का रूम बनाने के लिए 'Create Room' बटन पर क्लिक करें या नीचे दिए गए लाइव टूर्नामेंट्स में से किसी एक में शामिल हों।
          </p>
        </CardContent>
      </Card>


      {/* <AISuggestions /> */}

      <div>
        <h2 className="text-2xl font-bold mb-4">Live Tournaments</h2>
        <Tabs defaultValue="all" className="w-full">
          <div className="flex flex-col md:flex-row justify-between gap-4 mb-4">
            <TabsList className="grid grid-cols-3 w-full md:w-auto">
              <TabsTrigger value="all">All Modes</TabsTrigger>
              <TabsTrigger value="br">Battle Royale</TabsTrigger>
              <TabsTrigger value="cs">Clash Squad</TabsTrigger>
            </TabsList>
            <div className="relative md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input placeholder="Search rooms..." className="pl-10"/>
            </div>
          </div>
          
          <TabsContent value="all">
            {renderTournamentGrid(tournaments)}
          </TabsContent>
          <TabsContent value="br">
            {renderTournamentGrid(tournaments.filter(t => t.game === 'BR'))}
          </TabsContent>
          <TabsContent value="cs">
            {renderTournamentGrid(tournaments.filter(t => t.game === 'CS'))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
