
'use client';

import { useState, useEffect } from 'react';
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth, db } from '@/lib/firebase';
import { doc, onSnapshot, updateDoc, runTransaction, collection, query, orderBy, serverTimestamp, addDoc } from 'firebase/firestore';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import {
  Wallet,
  Coins,
  ArrowUpRight,
  ArrowDownLeft,
  PlusCircle,
  Banknote,
  RefreshCw,
  Loader2,
  Filter,
  Repeat,
  Landmark,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Timestamp } from 'firebase/firestore';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.1,
      duration: 0.5
    },
  }),
};

interface Transaction {
  id: string;
  type: string;
  amount: number;
  date: Timestamp;
  status: string;
  transactionType: 'credit' | 'debit';
}

function TransactionItem({ type, amount, date, status, transactionType }: Omit<Transaction, 'id'>) {
    const isCredit = transactionType === 'credit';
    const statusColors: { [key: string]: string } = {
      Success: 'text-green-400',
      Pending: 'text-yellow-400',
      Failed: 'text-red-500',
    }
    
    // Convert Firestore Timestamp to JS Date for formatting
    const formattedDate = date instanceof Timestamp ? date.toDate().toLocaleString() : 'Invalid Date';
  
    return (
      <div className="flex items-center justify-between py-3">
        <div className="flex items-center gap-3">
          {isCredit ? (
            <ArrowUpRight className="h-5 w-5 text-accent" />
          ) : (
            <ArrowDownLeft className="h-5 w-5 text-destructive" />
          )}
          <div>
            <p className="font-semibold">{type}</p>
            <p className="text-xs text-muted-foreground">{formattedDate}</p>
          </div>
        </div>
        <div className='text-right'>
           <p className={`font-bold ${isCredit ? 'text-accent' : 'text-destructive'}`}>
              {isCredit ? '+' : ''}{Math.abs(amount).toFixed(2)} Coins
          </p>
          <p className={`text-xs font-semibold ${statusColors[status] || 'text-muted-foreground'}`}>{status}</p>
        </div>
      </div>
    );
  }

export default function WalletPage() {
  const [user, authLoading] = useAuthState(auth);
  const router = useRouter();
  const { toast } = useToast();
  const [userData, setUserData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  const [isAddingMoney, setIsAddingMoney] = useState(false);
  const [addAmount, setAddAmount] = useState('');

  const [isConvertingMoney, setIsConvertingMoney] = useState(false);
  const [convertMoneyAmount, setConvertMoneyAmount] = useState('');

  const [isConvertingCoins, setIsConvertingCoins] = useState(false);
  const [convertCoinsAmount, setConvertCoinsAmount] = useState('');
  
  const [transactionHistory, setTransactionHistory] = useState<Transaction[]>([]);


  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      router.push('/login');
      return;
    }

    const unsubUser = onSnapshot(doc(db, "users", user.uid), (doc) => {
        if (doc.exists()) {
          const data = doc.data();
          setUserData({
            ...data,
            realMoneyBalance: data.realMoneyBalance || 0,
            walletBalance: data.walletBalance || 0,
          });
        }
        setLoading(false);
      });

    const transactionsQuery = query(collection(db, "users", user.uid, "transactions"), orderBy("date", "desc"));
    const unsubTransactions = onSnapshot(transactionsQuery, (snapshot) => {
        const history = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction));
        setTransactionHistory(history);
    });

    return () => {
        unsubUser();
        unsubTransactions();
    };

  }, [user, authLoading, router]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    // Simulate fetching new data
    setTimeout(() => setIsRefreshing(false), 1000);
  }

  const handleAddMoney = async () => {
    const amount = parseFloat(addAmount);
    if (!user || isNaN(amount) || amount <= 0) {
        toast({variant: 'destructive', title: 'Invalid Amount', description: 'Please enter a valid amount to deposit.'});
        return;
    }
    setIsAddingMoney(true);

    const userRef = doc(db, 'users', user.uid);
    const transactionsRef = collection(db, 'users', user.uid, 'transactions');
    
    try {
        await runTransaction(db, async (transaction) => {
            const userDoc = await transaction.get(userRef);
            if (!userDoc.exists()) throw new Error("User not found");

            const newRealMoney = (userDoc.data().realMoneyBalance || 0) + amount;
            transaction.update(userRef, { realMoneyBalance: newRealMoney });
        });

        toast({ title: 'Success!', description: `₹${amount} has been added to your real money balance.`});
        setAddAmount('');
    } catch (error) {
        toast({variant: 'destructive', title: 'Error', description: 'Could not add money to your wallet.'});
    } finally {
        setIsAddingMoney(false);
    }
  }

  const handleMoneyToCoinConversion = async () => {
    const amount = parseFloat(convertMoneyAmount);
    if (!user || isNaN(amount) || amount <= 0) {
        toast({variant: 'destructive', title: 'Invalid Amount', description: 'Please enter a valid amount to convert.'});
        return;
    }
     if (amount > userData.realMoneyBalance) {
        toast({variant: 'destructive', title: 'Insufficient Funds', description: 'You do not have enough real money to convert.'});
        return;
    }
    setIsConvertingMoney(true);

    const userRef = doc(db, 'users', user.uid);
    const transactionsRef = collection(db, 'users', user.uid, 'transactions');
    try {
        await runTransaction(db, async (transaction) => {
            const userDoc = await transaction.get(userRef);
            if (!userDoc.exists()) throw new Error("User not found");

            const currentData = userDoc.data();
            const newRealMoney = (currentData.realMoneyBalance || 0) - amount;
            const newCoins = (currentData.walletBalance || 0) + amount;

            transaction.update(userRef, {
                realMoneyBalance: newRealMoney,
                walletBalance: newCoins
            });
            
            // Log the conversion
            transaction.set(doc(transactionsRef), {
                type: 'Money to Coin',
                amount: amount,
                date: serverTimestamp(),
                status: 'Success',
                transactionType: 'credit'
            });
        });
        toast({ title: 'Conversion Successful!', description: `You have converted ₹${amount} to ${amount} coins.`});
        setConvertMoneyAmount('');
    } catch (error: any) {
        toast({variant: 'destructive', title: 'Conversion Failed', description: error.message || 'Could not complete the conversion.'});
    } finally {
        setIsConvertingMoney(false);
    }
  };
  
  const handleCoinToMoneyConversion = async () => {
    const amount = parseFloat(convertCoinsAmount);
    if (!user || isNaN(amount) || amount <= 0) {
        toast({variant: 'destructive', title: 'Invalid Amount', description: 'Please enter a valid amount to convert.'});
        return;
    }
     if (amount > userData.walletBalance) {
        toast({variant: 'destructive', title: 'Insufficient Coins', description: 'You do not have enough coins to convert.'});
        return;
    }
    setIsConvertingCoins(true);

    const userRef = doc(db, 'users', user.uid);
    const transactionsRef = collection(db, 'users', user.uid, 'transactions');
    try {
        await runTransaction(db, async (transaction) => {
            const userDoc = await transaction.get(userRef);
            if (!userDoc.exists()) throw new Error("User not found");

            const currentData = userDoc.data();
            const newRealMoney = (currentData.realMoneyBalance || 0) + amount;
            const newCoins = (currentData.walletBalance || 0) - amount;

            transaction.update(userRef, {
                realMoneyBalance: newRealMoney,
                walletBalance: newCoins
            });

             // Log the conversion
            transaction.set(doc(transactionsRef), {
                type: 'Coin to Money',
                amount: -amount,
                date: serverTimestamp(),
                status: 'Success',
                transactionType: 'debit'
            });

        });
        toast({ title: 'Conversion Successful!', description: `You have converted ${amount} coins to ₹${amount}.`});
        setConvertCoinsAmount('');
    } catch (error: any) {
        toast({variant: 'destructive', title: 'Conversion Failed', description: error.message || 'Could not complete the conversion.'});
    } finally {
        setIsConvertingCoins(false);
    }
  };


  if (loading || authLoading) {
    return (
        <div className="container max-w-4xl px-4 sm:px-6 py-6 space-y-6">
            <Skeleton className="h-8 w-1/3" />
            <Skeleton className="h-40 w-full rounded-2xl" />
            <div className="grid grid-cols-2 gap-4">
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
            </div>
            <Skeleton className="h-8 w-1/4 mt-4" />
             <div className="space-y-4">
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
            </div>
        </div>
    );
  }

  return (
    <div className="container max-w-4xl px-4 sm:px-6 py-6">
        <motion.div initial="hidden" animate="visible" variants={cardVariants} custom={0} className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold font-headline flex items-center gap-2">
                <Wallet className="h-8 w-8 text-primary" /> My Wallet
            </h1>
            <Button variant="ghost" size="icon" onClick={handleRefresh} disabled={isRefreshing}>
                <RefreshCw className={`h-5 w-5 ${isRefreshing ? 'animate-spin' : ''}`} />
            </Button>
        </motion.div>
        
        <div className="grid md:grid-cols-2 gap-6">
            <motion.div initial="hidden" animate="visible" variants={cardVariants} custom={1}>
                <Card className="rounded-2xl shadow-xl shadow-primary/10 border-primary/20 bg-card/80 backdrop-blur-sm h-full">
                    <CardHeader>
                        <CardDescription>Coin Balance (for Gameplay)</CardDescription>
                        <CardTitle className="text-5xl font-bold text-accent neon-accent flex items-center gap-2">
                             {userData?.walletBalance?.toFixed(2) || '0.00'} <Coins className="h-10 w-10" />
                        </CardTitle>
                    </CardHeader>
                </Card>
            </motion.div>
             <motion.div initial="hidden" animate="visible" variants={cardVariants} custom={2}>
                <Card className="rounded-2xl shadow-xl shadow-primary/10 border-primary/20 bg-card/80 backdrop-blur-sm h-full">
                    <CardHeader>
                        <CardDescription>Real Money Balance (₹)</CardDescription>
                        <CardTitle className="text-5xl font-bold text-white flex items-center gap-2">
                             ₹{userData?.realMoneyBalance?.toFixed(2) || '0.00'}
                        </CardTitle>
                    </CardHeader>
                </Card>
            </motion.div>
        </div>
        
         <motion.div initial="hidden" animate="visible" variants={cardVariants} custom={3} className="mt-6">
            <Card>
                <CardHeader>
                    <CardTitle>Bank Account</CardTitle>
                    <CardDescription>Manage your linked bank account for deposits and withdrawals.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Alert>
                        <Landmark className="h-4 w-4" />
                        <AlertTitle>Feature Coming Soon!</AlertTitle>
                        <AlertDescription>
                            The ability to add and manage bank accounts is under development.
                        </AlertDescription>
                    </Alert>
                </CardContent>
            </Card>
        </motion.div>
        
        <div className="grid md:grid-cols-2 gap-6 mt-6">
            <motion.div initial="hidden" animate="visible" variants={cardVariants} custom={4}>
                <Card>
                    <CardHeader>
                        <CardTitle>Convert Money to Coins</CardTitle>
                        <CardDescription>1 Rupee = 1 Coin. Coins are used to play tournaments.</CardDescription>
                    </CardHeader>
                    <CardContent className="flex flex-col sm:flex-row gap-4 items-end">
                        <div className="w-full sm:w-auto flex-grow">
                            <Label htmlFor="convert-money-amount">Amount to Convert (₹)</Label>
                            <Input id="convert-money-amount" type="number" placeholder={`Max: ₹${userData?.realMoneyBalance?.toFixed(2) || '0.00'}`} value={convertMoneyAmount} onChange={(e) => setConvertMoneyAmount(e.target.value)} />
                        </div>
                        <Button onClick={handleMoneyToCoinConversion} disabled={isConvertingMoney} className="w-full sm:w-auto btn-glow-accent bg-accent hover:bg-accent/90">
                            {isConvertingMoney ? <Loader2 className="animate-spin"/> : <Repeat className="mr-2"/>}
                            Convert to Coins
                        </Button>
                    </CardContent>
                </Card>
            </motion.div>
            <motion.div initial="hidden" animate="visible" variants={cardVariants} custom={5}>
                <Card>
                    <CardHeader>
                        <CardTitle>Convert Coins to Money</CardTitle>
                        <CardDescription>1 Coin = 1 Rupee. Convert your won coins to real money.</CardDescription>
                    </CardHeader>
                    <CardContent className="flex flex-col sm:flex-row gap-4 items-end">
                        <div className="w-full sm:w-auto flex-grow">
                            <Label htmlFor="convert-coins-amount">Coins to Convert</Label>
                            <Input id="convert-coins-amount" type="number" placeholder={`Max: ${userData?.walletBalance?.toFixed(2) || '0.00'}`} value={convertCoinsAmount} onChange={(e) => setConvertCoinsAmount(e.target.value)} />
                        </div>
                        <Button onClick={handleCoinToMoneyConversion} disabled={isConvertingCoins || !userData?.bankAccount} className="w-full sm:w-auto btn-glow">
                            {isConvertingCoins ? <Loader2 className="animate-spin"/> : <Repeat className="mr-2"/>}
                            Convert to Money
                        </Button>
                    </CardContent>
                     {!userData?.bankAccount && <CardDescription className="p-6 pt-2 text-destructive text-xs">You must add a bank account before converting coins to money.</CardDescription>}
                </Card>
            </motion.div>
        </div>


        <motion.div initial="hidden" animate="visible" variants={cardVariants} custom={6} className="mt-8">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">Coin Transaction History</h2>
                <Button variant="ghost" size="sm"><Filter className="h-4 w-4 mr-2" /> Filter</Button>
            </div>
            
            <Card className="bg-card/50">
                <CardContent className="divide-y divide-border p-0">
                    {loading ? (
                         <div className="p-6 space-y-4">
                            <Skeleton className="h-16 w-full" />
                            <Skeleton className="h-16 w-full" />
                            <Skeleton className="h-16 w-full" />
                        </div>
                    ) : transactionHistory.length > 0 ? (
                        transactionHistory.map((tx, i) => (
                             <motion.div key={tx.id} custom={i} initial="hidden" animate="visible" variants={cardVariants} className="px-6">
                                <TransactionItem {...tx as any} />
                             </motion.div>
                        ))
                    ) : (
                        <div className="text-center py-12 text-muted-foreground">
                            <p>No transactions yet.</p>
                            <p className="text-sm">Your transaction history will appear here.</p>
                        </div>
                    )}
                </CardContent>
            </Card>
        </motion.div>
    </div>
  );
}
