
'use client';

import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import {
  ShieldCheck,
  Sword,
  Trophy,
  Wallet,
  LogOut,
  Pencil,
  FileClock,
  Coins,
  Loader2,
  Medal,
  Award,
  Crown,
  Star,
  Settings,
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth, db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { doc, onSnapshot, updateDoc, setDoc, getDoc, collection, query, where } from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import Link from 'next/link';
import { type MatchProps, type MatchStatus } from '@/components/tournament/match-card';
import { FirePlayCard } from '@/components/profile/fire-play-card';

const achievements = [
    { icon: <Crown className="h-5 w-5 text-amber-400" />, title: "Tournament King", description: "Win 10 tournaments" },
    { icon: <Medal className="h-5 w-5 text-yellow-500" />, title: "Veteran Player", description: "Play 100 matches" },
    { icon: <Award className="h-5 w-5 text-sky-400" />, title: "Top Fragger", description: "Get 20+ kills in a match" },
    { icon: <Star className="h-5 w-5 text-green-400" />, title: "First Blood", description: "Win your first match" },
];

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

type HistoryMatchStatus = 'Won' | 'Lost' | 'Disqualified' | 'Pending Result' | 'Live';

export default function ProfilePage() {
  const [user, loading] = useAuthState(auth);
  const router = useRouter();
  const { toast } = useToast();
  const [userData, setUserData] = useState<any>(null);
  const [tournamentHistory, setTournamentHistory] = useState<MatchProps[]>([]);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.push('/login');
      return;
    }

    const unsubUser = onSnapshot(doc(db, "users", user.uid), (doc) => {
        if (doc.exists()) {
          const data = doc.data();
          setUserData({ uid: user.uid, ...data });
        } else {
          console.error("No user data found in Firestore!");
        }
      });
      
    const q = query(
      collection(db, "tournaments"),
      where("participants", "array-contains", user.uid),
      where("status", "in", ["completed", "cancelled"])
    );

    const unsubTournaments = onSnapshot(q, (querySnapshot) => {
        const history: MatchProps[] = [];
        querySnapshot.forEach((doc) => {
            const data = doc.data();
            const isWinner = data.winner?.uid === user.uid;
            
            let matchStatus: MatchStatus | HistoryMatchStatus = data.status;
            if (data.status === 'completed') {
                matchStatus = isWinner ? 'Won' : 'Lost';
            } else if (data.status === 'cancelled') {
                matchStatus = 'Disqualified';
            }

            history.push({
                id: doc.id,
                tournamentName: data.title,
                date: data.startTime.toDate().toISOString(),
                gameMode: data.gameMode,
                matchType: data.matchType,
                prize: data.prizePool,
                status: matchStatus as MatchStatus, // Casting here
            });
        });
        setTournamentHistory(history);
    });

    return () => {
        unsubUser();
        unsubTournaments();
    };

  }, [user, loading, router]);

  const handleLogout = async () => {
    await signOut(auth);
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out.",
    });
    router.push('/login');
  };

  const handleProfileUpdate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;
    setIsEditing(true);
    const form = new FormData(e.currentTarget);
    const newUsername = form.get('username') as string;
    const newGameUid = form.get('game-uid') as string;

    try {
      const userDocRef = doc(db, 'users', user.uid);
      await updateDoc(userDocRef, {
        name: newUsername,
        username: newUsername,
        gameUid: newGameUid,
      });
      toast({ title: "Profile Updated!" });
    } catch (error) {
      toast({ variant: 'destructive', title: "Update Failed", description: "Could not update profile." });
    } finally {
      setIsEditing(false);
    }
  };

  if (loading || !userData) {
    return (
      <div className="container mx-auto max-w-3xl px-4 py-6 sm:px-6 space-y-6">
        <Skeleton className="h-60 w-full max-w-md mx-auto rounded-lg" />
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-3xl px-4 py-6 sm:px-6">
      
      <FirePlayCard userData={userData} showVerificationButton={true} />

      {/* Wallet & Edit Profile */}
      <motion.div
        initial="hidden"
        animate="visible"
        variants={cardVariants}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2"
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wallet className="text-primary" /> Wallet
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-accent">{userData.walletBalance?.toFixed(2) || '0.00'} Coins</p>
            <p className="text-sm text-muted-foreground">Coin Balance</p>
            <Separator className="my-2"/>
            <p className="text-lg font-bold">₹{userData.realMoneyBalance?.toFixed(2) || '0.00'}</p>
            <p className="text-sm text-muted-foreground">Real Money</p>
             <Button asChild variant="link" className="px-0">
                <Link href="/wallet">Manage Wallet</Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Pencil className="text-primary" /> Profile Actions
            </CardTitle>
             <CardDescription>
                Update your details or log out.
             </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
             <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full">
                  <Pencil className="mr-2 h-4 w-4" />
                  Edit Profile
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-primary/30">
                <DialogHeader>
                  <DialogTitle>Edit Profile</DialogTitle>
                  <DialogDescription>
                    Update your username and game UID here.
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleProfileUpdate}>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="username" className="text-right">
                        Username
                      </Label>
                      <Input id="username" name="username" defaultValue={userData.username || userData.name} className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="game-uid" className="text-right">
                        Game UID
                      </Label>
                      <Input id="game-uid" name="game-uid" defaultValue={userData.gameUid} className="col-span-3" />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit" className="btn-glow" disabled={isEditing}>
                      {isEditing ? <Loader2 className="animate-spin" /> : 'Save Changes'}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
            <Button variant="destructive" className="w-full" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              Log Out
            </Button>
          </CardContent>
        </Card>
      </motion.div>
      
      {/* Achievements */}
      <motion.div
        initial="hidden"
        animate="visible"
        variants={cardVariants}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="mt-6"
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="text-primary" /> Achievements
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {achievements.map((ach, i) => (
                <div key={i} className="flex items-center gap-4 rounded-lg bg-secondary/50 p-3">
                  {ach.icon}
                  <div>
                    <p className="font-semibold">{ach.title}</p>
                    <p className="text-xs text-muted-foreground">{ach.description}</p>
                  </div>
                </div>
              ))}
          </CardContent>
        </Card>
      </motion.div>

      {/* Tournament History */}
      <motion.div
        initial="hidden"
        animate="visible"
        variants={cardVariants}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="mt-6"
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileClock className="text-primary" /> Tournament History
            </CardTitle>
          </CardHeader>
          <CardContent>
             {tournamentHistory.length > 0 ? (
                <div className="space-y-3">
                {tournamentHistory.map((t) => {
                    const statusConfig = {
                        Won: 'bg-green-500/20 text-green-400 border-green-500/30',
                        Lost: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
                        Disqualified: 'bg-red-500/20 text-red-400 border-red-500/30',
                        // These are fallbacks from MatchCard status, won't be used if logic is correct
                        'pending': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
                        'live': 'bg-primary/20 text-primary border-primary/30',
                        'completed': 'bg-gray-500/20 text-gray-400 border-gray-500/30',
                        'cancelled': 'bg-red-500/20 text-red-400 border-red-500/30',
                    };
                    const statusVariant = statusConfig[t.status as keyof typeof statusConfig] || 'bg-gray-500/20 text-gray-400 border-gray-500/30';
                    return (
                        <div key={t.id} className="flex items-center justify-between rounded-lg bg-secondary/50 p-3">
                            <div>
                                <p className="font-semibold">{t.tournamentName}</p>
                                <p className="text-sm text-muted-foreground">{t.prize ? `Prize: ${t.prize} Coins`: 'Participation'}</p>
                            </div>
                            <Badge className={`border capitalize ${statusVariant}`}>
                                {t.status}
                            </Badge>
                        </div>
                    )
                })}
                </div>
             ) : (
                <p className="text-muted-foreground text-center py-4">No past tournaments found.</p>
             )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
