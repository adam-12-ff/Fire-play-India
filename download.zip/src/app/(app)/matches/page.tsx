
'use client';

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MatchCard, type MatchProps } from "@/components/tournament/match-card";
import { useEffect, useState } from "react";
import { useAuthState } from "react-firebase-hooks/auth";
import { auth, db } from "@/lib/firebase";
import { collection, onSnapshot, query, where, getDocs, QuerySnapshot, DocumentData } from "firebase/firestore";
import { Loader2 } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function MatchesPage() {
  const [user, authLoading] = useAuthState(auth);
  const [loading, setLoading] = useState(true);
  const [ongoingMatches, setOngoingMatches] = useState<MatchProps[]>([]);
  const [completedMatches, setCompletedMatches] = useState<MatchProps[]>([]);

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      setLoading(false);
      return;
    }

    const processAndSetMatches = (
      joinedSnapshot: QuerySnapshot<DocumentData>,
      hostedSnapshot: QuerySnapshot<DocumentData>
    ) => {
      const allMatchesMap = new Map<string, MatchProps>();

      const processSnapshot = (snapshot: QuerySnapshot<DocumentData>, isHosted: boolean) => {
        snapshot.forEach((doc) => {
          const data = doc.data();
          // If a match is already processed (e.g., user joined a match they host), update its isHost status
          if (allMatchesMap.has(doc.id)) {
            const existingMatch = allMatchesMap.get(doc.id)!;
            if (isHosted) {
                existingMatch.isHost = true;
            }
          } else {
             const match: MatchProps = {
                id: doc.id,
                tournamentName: data.title,
                date: data.startTime.toDate().toISOString(),
                gameMode: data.gameMode,
                matchType: data.matchType,
                status: data.status,
                prize: data.prizePool,
                isHost: isHosted,
            };
            allMatchesMap.set(doc.id, match);
          }
        });
      };
      
      processSnapshot(joinedSnapshot, false);
      processSnapshot(hostedSnapshot, true);

      const ongoing: MatchProps[] = [];
      const completed: MatchProps[] = [];

      allMatchesMap.forEach((match) => {
        if (match.status === 'completed' || match.status === 'cancelled') {
          completed.push(match);
        } else {
          ongoing.push(match);
        }
      });
      
      // Sort by date, newest first
      ongoing.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      completed.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

      setOngoingMatches(ongoing);
      setCompletedMatches(completed);
      setLoading(false);
    };

    const joinedQuery = query(
      collection(db, "tournaments"),
      where("participants", "array-contains", user.uid)
    );
    
    const hostedQuery = query(
      collection(db, "tournaments"),
      where("hostId", "==", user.uid)
    );

    const unsubJoined = onSnapshot(joinedQuery, async (joinedSnapshot) => {
      const hostedSnapshot = await getDocs(hostedQuery);
      processAndSetMatches(joinedSnapshot, hostedSnapshot);
    });

    const unsubHosted = onSnapshot(hostedQuery, async (hostedSnapshot) => {
      const joinedSnapshot = await getDocs(joinedQuery);
      processAndSetMatches(joinedSnapshot, hostedSnapshot);
    });

    return () => {
      unsubJoined();
      unsubHosted();
    };
  }, [user, authLoading]);

  if (loading || authLoading) {
    return (
      <div className="container flex items-center justify-center py-6">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }
  
   if (!user) {
    return (
      <div className="container text-center py-12">
        <p className="text-muted-foreground">Please log in to see your matches.</p>
        <Button asChild variant="link" className="text-accent">
          <Link href="/login">Log In</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container px-4 sm:px-6 py-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold font-headline">My Matches</h1>
        <p className="text-muted-foreground">Track your ongoing games and review your history.</p>
      </div>

      <Tabs defaultValue="ongoing" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="ongoing">Ongoing</TabsTrigger>
          <TabsTrigger value="history">Match History</TabsTrigger>
        </TabsList>
        <TabsContent value="ongoing">
          {ongoingMatches.length > 0 ? (
            <div className="space-y-4 mt-4">
              {ongoingMatches.map((match) => <MatchCard key={match.id} {...match} />)}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <p>No ongoing matches right now.</p>
              <Button asChild variant="link" className="text-accent">
                <Link href="/">Find a new challenge!</Link>
              </Button>
            </div>
          )}
        </TabsContent>
        <TabsContent value="history">
          {completedMatches.length > 0 ? (
            <div className="space-y-4 mt-4">
              {completedMatches.map((match) => <MatchCard key={match.id} {...match} />)}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <p>Your match history is empty.</p>
              <p className="text-sm">Play a game to see your stats here.</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
