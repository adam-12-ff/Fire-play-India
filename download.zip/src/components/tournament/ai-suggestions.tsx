
'use client';

import { useState, useEffect } from 'react';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Sparkles } from 'lucide-react';
import type { TournamentSuggestionOutput } from '@/ai/flows/predictive-tournament-suggestions';
// import { getTournamentSuggestions } from '@/ai/flows/predictive-tournament-suggestions';

// Mock data to simulate AI response
const mockSuggestions: TournamentSuggestionOutput = {
  suggestedTournaments: [
    {
      tournamentId: 's1',
      tournamentName: 'Pro Series: Clash',
      reason: 'Based on your recent wins in CS mode.',
    },
    {
      tournamentId: 's2',
      tournamentName: 'Rookie Rumble',
      reason: 'A great place to hone your BR skills.',
    },
    {
      tournamentId: 's3',
      tournamentName: 'Squad Goals Weekly',
      reason: 'You frequently play 4v4 matches.',
    },
    {
      tournamentId: 's4',
      tournamentName: 'Solo King',
      reason: 'You excel in 1v1 encounters.',
    },
  ],
};

export function AISuggestions() {
  const [suggestions, setSuggestions] = useState<
    TournamentSuggestionOutput['suggestedTournaments']
  >([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // In a real app, you would uncomment this to call the Genkit flow
    /*
    const fetchSuggestions = async () => {
      try {
        setLoading(true);
        const result = await getTournamentSuggestions({
          userId: 'user123', // Replace with actual user ID
          gameHistory: ['game1', 'game3'],
          skillLevel: 'Intermediate',
          preferences: '4v4, CS mode',
        });
        setSuggestions(result.suggestedTournaments);
      } catch (error) {
        console.error("Failed to fetch AI suggestions:", error);
        // Handle error case, maybe show a message
      } finally {
        setLoading(false);
      }
    };
    fetchSuggestions();
    */
    
    // Simulating API call with mock data
    const timer = setTimeout(() => {
      setSuggestions(mockSuggestions.suggestedTournaments);
      setLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="my-8">
      <h2 className="flex items-center gap-2 text-2xl font-bold mb-4 px-4 sm:px-6">
        <Sparkles className="w-6 h-6 neon-accent" />
        Suggested For You
      </h2>
      <Carousel
        opts={{
          align: 'start',
          loop: false,
        }}
        className="w-full"
      >
        <CarouselContent className="-ml-2 sm:-ml-4">
          {loading
            ? Array.from({ length: 3 }).map((_, index) => (
                <CarouselItem
                  key={index}
                  className="pl-4 basis-4/5 sm:basis-1/2 lg:basis-1/3"
                >
                  <Skeleton className="w-full h-48 rounded-lg" />
                </CarouselItem>
              ))
            : suggestions.map((suggestion) => (
                <CarouselItem
                  key={suggestion.tournamentId}
                  className="pl-4 basis-4/5 sm:basis-1/2 lg:basis-1/3"
                >
                  <Card className="bg-card/70 border-primary/20 backdrop-blur-sm">
                    <CardContent className="p-4 flex flex-col justify-between h-48">
                      <div>
                        <h3 className="font-bold text-lg text-primary">
                          {suggestion.tournamentName}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-2 italic">
                          &quot;{suggestion.reason}&quot;
                        </p>
                      </div>
                      <p className="text-xs text-accent font-semibold self-start">
                        AI Recommendation
                      </p>
                    </CardContent>
                  </Card>
                </CarouselItem>
              ))}
        </CarouselContent>
        <div className="hidden sm:block">
            <CarouselPrevious className="ml-16" />
            <CarouselNext className="mr-16" />
        </div>
      </Carousel>
    </div>
  );
}
