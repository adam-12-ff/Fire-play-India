
'use client';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Ticket } from "lucide-react";
import { useState } from "react";
import { doc, getDoc, updateDoc, arrayUnion, runTransaction } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { useAuthState } from "react-firebase-hooks/auth";

// This component is no longer used directly by TournamentCard but can be kept for other purposes if needed.
// For example, joining a private room via ID/Password could use this.
export function JoinTournamentDialog({
  children,
  tournamentId,
  entryFee,
}: {
  children: React.ReactNode;
  tournamentId: string;
  entryFee: number;
}) {
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const [user] = useAuthState(auth);

  const handleJoin = async () => {
    if (!user) {
      toast({ variant: 'destructive', title: 'Not Logged In', description: 'You must be logged in to join a tournament.' });
      return;
    }
    if (!password) {
      toast({ variant: 'destructive', title: 'Password Required', description: 'Please enter the room password.' });
      return;
    }
    setIsLoading(true);
    
    const tournamentRef = doc(db, "tournaments", tournamentId);
    const userRef = doc(db, "users", user.uid);

    try {
      await runTransaction(db, async (transaction) => {
        const tournamentDoc = await transaction.get(tournamentRef);
        const userDoc = await transaction.get(userRef);

        if (!tournamentDoc.exists()) {
          throw new Error("Tournament not found.");
        }
        if (!userDoc.exists()) {
            throw new Error("User data not found.");
        }

        const tournamentData = tournamentDoc.data();
        const userData = userDoc.data();

        // Check password (not implemented in schema yet, skipping check)
        // if (tournamentData.password && tournamentData.password !== password) {
        //   throw new Error("Incorrect password.");
        // }

        if (tournamentData.participants.length >= tournamentData.maxPlayers) {
            throw new Error("Tournament is full.");
        }
        
        if (userData.walletBalance < entryFee) {
            throw new Error("Insufficient wallet balance.");
        }

        // Deduct entry fee and add user to participants
        const newBalance = userData.walletBalance - entryFee;
        transaction.update(userRef, { walletBalance: newBalance });
        transaction.update(tournamentRef, {
            participants: arrayUnion({ uid: user.uid, name: user.displayName })
        });
      });

      toast({ title: 'Successfully Joined!', description: `Entry fee of ${entryFee} Coins has been deducted.` });
      // Close dialog on success?
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Join Failed',
        description: error.message || 'Could not join the tournament.',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[425px] bg-card border-primary/30">
        <DialogHeader>
          <DialogTitle className="text-2xl font-headline text-primary">Join Room</DialogTitle>
          <DialogDescription>
            Enter the room password to join this tournament. Good luck!
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="room-id">Room ID</Label>
            <Input id="room-id" value={tournamentId} readOnly className="font-mono"/>
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" placeholder="Enter room password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <div className="text-sm text-center bg-secondary p-3 rounded-md border border-border">
            Entry fee of <span className="font-bold text-accent">{entryFee} Coins</span> will be deducted from your wallet.
          </div>
        </div>
        <DialogFooter>
          <Button onClick={handleJoin} disabled={isLoading} className="w-full btn-glow-accent bg-accent hover:bg-accent/90 text-accent-foreground font-bold">
            {isLoading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Ticket className="mr-2 h-5 w-5"/>}
            {isLoading ? 'Joining...' : 'Confirm and Join'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
