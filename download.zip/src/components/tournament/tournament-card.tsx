
import Image from "next/image";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Users, Ticket, Trophy, Info, ArrowRight } from "lucide-react";
import Link from "next/link";

export type TournamentCardProps = {
  id: string;
  name: string;
  game: 'BR' | 'CS';
  mode: 'Solo' | 'Duo' | 'Squad';
  prize: number;
  entryFee: number;
  participants: number;
  maxParticipants: number;
  status: 'Open' | 'Full' | 'Starting Soon' | 'Live';
  imageUrl: string;
  aiHint: string;
};

export function TournamentCard({ tournament }: { tournament: TournamentCardProps }) {
  const isFull = tournament.participants >= tournament.maxParticipants;
  const statusColor = {
    'Open': 'bg-accent/20 text-accent border-accent/30',
    'Full': 'bg-red-500/20 text-red-400 border-red-500/30',
    'Starting Soon': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    'Live': 'bg-primary/20 text-primary border-primary/30',
  };

  return (
    <Link href={`/tournaments/${tournament.id}`} className="block">
      <Card className="group relative overflow-hidden border-2 border-border bg-card/50 transition-all hover:border-primary/50 hover:shadow-xl hover:shadow-primary/10 h-full flex flex-col">
        <CardHeader className="p-0">
          <div className="relative h-40 w-full">
            <Image
              src={tournament.imageUrl}
              alt={tournament.name}
              data-ai-hint={tournament.aiHint}
              fill
              className="object-cover transition-transform duration-300 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent" />
            <div className="absolute bottom-2 left-4">
              <h3 className="text-xl font-bold text-white">{tournament.name}</h3>
              <div className="flex gap-2 mt-1">
                <Badge variant="secondary" className="bg-black/50 text-white">{tournament.game}</Badge>
                <Badge variant="secondary" className="bg-black/50 text-white">{tournament.mode}</Badge>
              </div>
            </div>
            <Badge className={`absolute top-2 right-2 border ${statusColor[tournament.status]}`}>{tournament.status}</Badge>
          </div>
        </CardHeader>
        <CardContent className="p-4 space-y-4 flex-grow">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Ticket className="h-5 w-5 text-primary" />
              <div>
                <p className="text-muted-foreground">Entry</p>
                <p className="font-semibold">{tournament.entryFee} Coins</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-amber-400" />
              <div>
                <p className="text-muted-foreground">Prize</p>
                <p className="font-semibold">{tournament.prize.toLocaleString()} Coins</p>
              </div>
            </div>
          </div>
          <div>
            <div className="flex justify-between items-center mb-1 text-xs text-muted-foreground">
              <div className="flex items-center gap-1"><Users className="h-3 w-3" /> Participants</div>
              <span>{tournament.participants} / {tournament.maxParticipants}</span>
            </div>
            <Progress value={(tournament.participants / tournament.maxParticipants) * 100} className="h-2 [&>div]:bg-primary" />
          </div>
        </CardContent>
        <CardFooter className="p-4 pt-0">
            <Button disabled={isFull} className="w-full font-bold text-base h-11 btn-glow">
              {isFull ? 'Room Full' : 'View Details'}
              {!isFull && <ArrowRight className="ml-2 h-4 w-4"/>}
            </Button>
        </CardFooter>
      </Card>
    </Link>
  );
}
