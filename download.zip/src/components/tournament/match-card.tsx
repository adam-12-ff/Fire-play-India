
'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Swords, HeartPulse, Trophy, Video, Crown, ArrowRight } from "lucide-react";
import { format } from "date-fns";
import { useEffect, useState } from "react";
import Link from "next/link";

export type MatchStatus = 'pending' | 'live' | 'completed' | 'cancelled' | 'Won' | 'Lost' | 'Disqualified';

export type MatchProps = {
  id: string;
  tournamentName: string;
  date: string;
  gameMode: 'BR' | 'CS';
  matchType: 'Solo' | 'Duo' | 'Squad';
  status: MatchStatus;
  prize: number;
  kills?: number;
  damage?: number;
  isHost?: boolean;
};

const statusConfig: Record<MatchStatus, { variant: "default" | "secondary" | "destructive" | "outline"; className: string; }> = {
    pending: {
        variant: "secondary",
        className: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    },
    live: {
        variant: "default",
        className: "bg-primary/20 text-primary border-primary/30 animate-pulse",
    },
    completed: {
        variant: "outline",
        className: "bg-gray-500/20 text-gray-400 border-gray-500/30",
    },
    cancelled: {
        variant: "destructive",
        className: "bg-red-500/20 text-red-400 border-red-500/30",
    },
    Won: {
        variant: "outline",
        className: "bg-green-500/20 text-green-400 border-green-500/30",
    },
    Lost: {
        variant: "outline",
        className: "bg-gray-500/20 text-gray-400 border-gray-500/30",
    },
    Disqualified: {
        variant: "destructive",
        className: "bg-red-500/20 text-red-400 border-red-500/30",
    },
}

function StatItem({ icon, label, value }: { icon: React.ReactNode, label: string, value: string | number}) {
    return (
        <div className="flex items-center gap-2 text-sm">
            <div className="text-primary">{icon}</div>
            <div>
                <p className="font-semibold">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
            </div>
        </div>
    )
}

export function MatchCard(props: MatchProps) {
    const config = statusConfig[props.status];
    const [formattedDate, setFormattedDate] = useState('');

    useEffect(() => {
        setFormattedDate(format(new Date(props.date), "PPP p"));
    }, [props.date]);

    if (!config) {
        return null;
    }

    return (
        <Card className="bg-card/50 transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10">
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div>
                        <CardTitle className="text-xl font-bold">{props.tournamentName}</CardTitle>
                        <CardDescription className="text-xs">
                            {formattedDate || 'Loading date...'}
                        </CardDescription>
                    </div>
                     <Badge className={`border capitalize ${config.className}`}>{props.status}</Badge>
                </div>
                 <div className="flex gap-2 pt-2">
                    <Badge variant="secondary">{props.gameMode}</Badge>
                    <Badge variant="secondary">{props.matchType}</Badge>
                    {props.isHost && <Badge variant="default" className="bg-primary/80 text-white">Hosting</Badge>}
                </div>
            </CardHeader>
            <CardContent>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div className="flex items-center gap-4 sm:gap-6">
                        {props.kills !== undefined && (
                             <StatItem icon={<Swords size={20} />} label="Kills" value={props.kills} />
                        )}
                        {props.damage !== undefined && (
                            <StatItem icon={<HeartPulse size={20} />} label="Damage" value={props.damage} />
                        )}
                         <StatItem icon={<Trophy size={20} />} label="Prize" value={`${props.prize.toLocaleString()} Coins`} />
                    </div>
                     <Button asChild className="w-full sm:w-auto btn-glow">
                        <Link href={`/tournaments/${props.id}`}>
                            {props.isHost && (props.status === 'pending' || props.status === 'live') ? (
                                <>
                                <Crown className="mr-2 h-4 w-4" />
                                Manage
                                </>
                            ) : (
                                <>
                                View Details
                                <ArrowRight className="ml-2 h-4 w-4" />
                                </>
                            )}
                        </Link>
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}
