
"use client";

import { useFormContext } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { useCreateTournamentStore } from "@/hooks/use-create-tournament-store";
import { type TournamentData, tournamentSchema } from "@/lib/validators/tournament";
import { ArrowLeft, ArrowRight, CheckCircle, Loader2 } from "lucide-react";
import { useState } from "react";

export function FormNavigation() {
  const { currentStep, nextStep, prevStep } = useCreateTournamentStore();
  const form = useFormContext<TournamentData>();
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isFirstStep = currentStep === 1;
  const isLastStep = currentStep === 4;

  const handleNext = async () => {
    setIsLoading(true);
    let fieldsToValidate: (keyof TournamentData)[] = [];
    if (currentStep === 1) fieldsToValidate = ['gameMode', 'matchType'];
    if (currentStep === 2) fieldsToValidate = ['title', 'entryFee', 'visibility'];
    if (currentStep === 3) fieldsToValidate = ['presetMode'];

    const isValid = await form.trigger(fieldsToValidate);
    if (isValid) {
      // Sync form data to store before moving to next step
      const data = form.getValues();
      useCreateTournamentStore.getState().setFormData(data);
      nextStep();
    }
    setIsLoading(false);
  };

  const handleSubmit = async (e: React.MouseEvent<HTMLButtonElement>) => {
     e.preventDefault();
    setIsSubmitting(true);
    await form.handleSubmit(useCreateTournamentStore.getState().setFormData)();
    const isFormValid = await form.trigger();
    
    if (isFormValid) {
        // The submission logic is now in the parent form component.
        // We just need to trigger the form's submit handler.
        const submitter = e.currentTarget.form;
        if (submitter) {
            // A bit of a hack to trigger the parent form's onSubmit
             submitter.requestSubmit();
        }
    } else {
      setIsSubmitting(false); // Only set to false if form is not valid, otherwise parent handles it.
    }
  }
  
  return (
    <div className="mt-8 pt-6 border-t border-border flex justify-between items-center">
      <Button
        type="button"
        variant="outline"
        onClick={prevStep}
        disabled={isFirstStep}
        className={isFirstStep ? "invisible" : "visible"}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back
      </Button>

      {isLastStep ? (
        <Button type="submit" onClick={handleSubmit} className="btn-glow-accent bg-accent hover:bg-accent/90" disabled={isSubmitting}>
          {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4" />}
          {isSubmitting ? 'Creating...' : 'Create Tournament'}
        </Button>
      ) : (
        <Button type="button" onClick={handleNext} className="btn-glow" disabled={isLoading}>
          {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> :  <ArrowRight className="ml-2 h-4 w-4" />}
          {isLoading ? 'Checking...' : 'Next'}
        </Button>
      )}
    </div>
  );
}
