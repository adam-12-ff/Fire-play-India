
"use client";

import { useState } from "react";
import {
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { type UseFormReturn } from "react-hook-form";
import { type TournamentData } from "@/lib/validators/tournament";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info, Receipt, Sparkles, Trophy, Lock, Globe } from "lucide-react";
import { useEffect, useMemo } from "react";
import { calculatePlatformFee, getStartTime } from "@/lib/tournament-utils";
import { generateRoomName } from "@/ai/flows/auto-room-name";
import { useCreateTournamentStore } from "@/hooks/use-create-tournament-store";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

export function Step2Info({ form }: { form: UseFormReturn<TournamentData> }) {
  const { watch, setValue, getValues, trigger } = form;
  const { formData } = useCreateTournamentStore();
  const [isGenerating, setIsGenerating] = useState(false);

  const entryFee = watch("entryFee");
  const maxPlayers = formData.maxPlayers;
  const gameMode = formData.gameMode;
  const matchType = formData.matchType;
  const tournamentId = getValues("id");

  useEffect(() => {
    setValue('startTime', getStartTime());
  }, [setValue]);

  const platformFee = useMemo(() => {
    return calculatePlatformFee(entryFee || 0);
  }, [entryFee]);

  const totalPrizePool = useMemo(() => {
    if (!entryFee || !maxPlayers) return 0;
    
    // Special case for CS 1v1
    if(gameMode === 'CS' && matchType === 'Solo') {
      return entryFee * 2;
    }

    const totalCollection = entryFee * maxPlayers;
    const totalPlatformFee = platformFee * maxPlayers;
    return totalCollection - totalPlatformFee;
  }, [entryFee, maxPlayers, platformFee, gameMode, matchType]);

  useEffect(() => {
    setValue('platformFee', platformFee);
    setValue('prizePool', totalPrizePool);
  }, [platformFee, totalPrizePool, setValue]);

  const handleGenerateTitle = async () => {
    setIsGenerating(true);
    try {
      const result = await generateRoomName({
        gameMode: gameMode,
        roomSize: matchType,
      });
      if (result.roomName) {
        setValue('title', result.roomName, { shouldValidate: true });
      }
    } catch (error) {
      console.error("Failed to generate room name:", error);
      // Optionally, show a toast notification for the error
    } finally {
      setIsGenerating(false);
    }
  };
  
  const totalEntryFee = (entryFee || 0) + platformFee;

  return (
    <div className="space-y-6">
      <FormField
        control={form.control}
        name="id"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Tournament ID</FormLabel>
            <FormControl>
              <Input {...field} readOnly className="font-mono bg-muted/50" />
            </FormControl>
            <FormDescription>
              यह आपके टूर्नामेंट के लिए यूनिक आईडी है।
            </FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />
      <FormField
        control={form.control}
        name="title"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Title</FormLabel>
            <div className="flex gap-2">
              <FormControl>
                <Input placeholder="e.g. Weekend Warriors" {...field} className="h-12" />
              </FormControl>
              <Button
                type="button"
                variant="outline"
                size="icon"
                className="h-12 w-12 flex-shrink-0 btn-glow"
                onClick={handleGenerateTitle}
                disabled={isGenerating}
              >
                <Sparkles className={`h-5 w-5 ${isGenerating ? 'animate-spin' : ''}`} />
                <span className="sr-only">Generate Title</span>
              </Button>
            </div>
            <FormMessage />
          </FormItem>
        )}
      />
      
      <FormField
        control={form.control}
        name="entryFee"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Entry Fee (Coins)</FormLabel>
            <FormControl>
              <Input
                type="number"
                placeholder="e.g. 50"
                {...field}
                onChange={e => {
                  const value = e.target.value;
                  field.onChange(value === '' ? '' : Number(value));
                }}
                className="h-12"
              />
            </FormControl>
             <FormDescription>
              यह बेस प्रवेश शुल्क है। <span className="font-bold">{platformFee.toFixed(2)} Coins</span> का प्लेटफ़ॉर्म शुल्क इसके ऊपर जोड़ा जाएगा। प्रति खिलाड़ी कुल शुल्क: <span className="font-bold">{totalEntryFee.toFixed(2)} Coins</span>।
            </FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />

       <FormField
        control={form.control}
        name="visibility"
        render={({ field }) => (
          <FormItem className="space-y-3">
            <FormLabel>Room Visibility</FormLabel>
            <FormDescription>
              सार्वजनिक कमरे लॉबी में सभी को दिखाई देते हैं। निजी कमरे केवल आईडी के माध्यम से ही एक्सेस किए जा सकते हैं।
            </FormDescription>
            <FormControl>
              <RadioGroup
                onValueChange={field.onChange}
                defaultValue={field.value}
                className="grid grid-cols-2 gap-4"
              >
                <FormItem>
                  <RadioGroupItem value="public" id="public" className="peer sr-only" />
                  <Label
                    htmlFor="public"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    <Globe className="mb-3 h-6 w-6" />
                    Public
                  </Label>
                </FormItem>

                <FormItem>
                  <RadioGroupItem value="private" id="private" className="peer sr-only" />
                  <Label
                    htmlFor="private"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    <Lock className="mb-3 h-6 w-6" />
                    Private
                  </Label>
                </FormItem>
              </RadioGroup>
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      {totalPrizePool > 0 && (
         <Alert className="border-green-500/30 bg-green-500/10 text-green-400">
          <Trophy className="h-4 w-4 text-current" />
          <AlertTitle className="text-current">Total Prize Pool</AlertTitle>
          <AlertDescription>
            कुल पुरस्कार पूल <span className="font-bold">{totalPrizePool.toFixed(2)} Coins</span> होगा।
          </AlertDescription>
        </Alert>
      )}

      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Auto-Cancellation</AlertTitle>
        <AlertDescription>
            टूर्नामेंट 30 मिनट में स्वचालित रूप से शुरू हो जाएगा। यदि तब तक कोई खिलाड़ी शामिल नहीं होता है, तो इसे रद्द कर दिया जाएगा और सभी प्रवेश शुल्क वापस कर दिए जाएंगे।
        </AlertDescription>
      </Alert>

    </div>
  );
}
