
"use client";

import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { type UseFormReturn } from "react-hook-form";
import { type TournamentData } from "@/lib/validators/tournament";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Users } from "lucide-react";
import { useEffect, useMemo } from "react";
import { getMaxPlayers } from "@/lib/tournament-utils";
import { AnimatePresence, motion } from "framer-motion";

export function Step1GameMode({ form }: { form: UseFormReturn<TournamentData> }) {
  const { watch, setValue, trigger } = form;
  const gameMode = watch("gameMode");
  const matchType = watch("matchType");

  const maxPlayers = useMemo(() => {
    if (gameMode && matchType) {
      return getMaxPlayers(gameMode, matchType);
    }
    return 0;
  }, [gameMode, matchType]);

  useEffect(() => {
    setValue('maxPlayers', maxPlayers);
  }, [maxPlayers, setValue]);

  useEffect(() => {
    if(gameMode === 'BR') {
        setValue('rounds', undefined);
    } else {
        setValue('rounds', '7');
        trigger('rounds');
    }
  }, [gameMode, setValue, trigger])

  return (
    <div className="space-y-6">
      <FormField
        control={form.control}
        name="gameMode"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Game Mode</FormLabel>
            <Select onValueChange={field.onChange} defaultValue={field.value}>
              <FormControl>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Select a game mode" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                <SelectItem value="BR">Battle Royale (BR)</SelectItem>
                <SelectItem value="CS">Clash Squad (CS)</SelectItem>
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )}
      />
      <FormField
        control={form.control}
        name="matchType"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Match Type</FormLabel>
            <Select onValueChange={field.onChange} defaultValue={field.value}>
              <FormControl>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Select a match type" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                <SelectItem value="Solo">Solo</SelectItem>
                <SelectItem value="Duo">Duo</SelectItem>
                <SelectItem value="Squad">Squad</SelectItem>
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )}
      />

       <AnimatePresence>
        {gameMode === 'CS' && (
           <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
           >
            <FormField
                control={form.control}
                name="rounds"
                render={({ field }) => (
                <FormItem>
                    <FormLabel>Rounds</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                        <SelectTrigger className="h-12">
                        <SelectValue placeholder="Select number of rounds" />
                        </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                        <SelectItem value="7">7 Rounds</SelectItem>
                        <SelectItem value="13">13 Rounds</SelectItem>
                        <SelectItem value="15">15 Rounds</SelectItem>
                    </SelectContent>
                    </Select>
                    <FormMessage />
                </FormItem>
                )}
            />
           </motion.div>
        )}
      </AnimatePresence>

      {maxPlayers > 0 && (
        <Alert className="border-accent/30 bg-accent/10">
          <Users className="h-4 w-4 text-accent" />
          <AlertTitle className="text-accent">Max Players/Teams</AlertTitle>
          <AlertDescription>
            This tournament will support a maximum of{" "}
            <span className="font-bold">{maxPlayers}</span>{" "}
            {matchType !== 'Solo' ? 'teams' : 'players'}.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
