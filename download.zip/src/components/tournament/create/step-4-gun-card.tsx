
"use client";

import {
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { type UseFormReturn } from "react-hook-form";
import { type TournamentData } from "@/lib/validators/tournament";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Gem, ShieldCheck } from "lucide-react";
import { Step5Confirm } from "./step-5-confirm";

export function Step4GunCard({ form }: { form: UseFormReturn<TournamentData> }) {
  const gunCardEnabled = form.watch("gunCardSupport");
  
  return (
    <div className="space-y-6">
      <FormField
        control={form.control}
        name="gunCardSupport"
        render={({ field }) => (
          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
            <div className="space-y-0.5">
              <FormLabel className="text-base">Enable Gun Card Boost</FormLabel>
              <FormDescription>
                खिलाड़ियों को शामिल होने पर कॉइन-आधारित बूस्ट का उपयोग करने की अनुमति दें।
              </FormDescription>
            </div>
            <FormControl>
              <Switch
                checked={field.value}
                onCheckedChange={field.onChange}
              />
            </FormControl>
          </FormItem>
        )}
      />

      {gunCardEnabled && (
        <Alert>
          <Gem className="h-4 w-4" />
          <AlertTitle>Gun Card Boost is Active!</AlertTitle>
          <AlertDescription>
            इस टूर्नामेंट में शामिल होने वाले खिलाड़ियों के पास गन कार्ड बूस्ट लगाने का विकल्प होगा। इससे भागीदारी बढ़ सकती है।
          </AlertDescription>
        </Alert>
      )}

      <Alert>
        <ShieldCheck className="h-4 w-4" />
        <AlertTitle>Confirm & Create</AlertTitle>
        <AlertDescription>
          Please review all the details below. Once created, you cannot edit these settings.
        </AlertDescription>
      </Alert>

      <Step5Confirm form={form} />
    </div>
  );
}
