
"use client";

import {
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { type UseFormReturn } from "react-hook-form";
import { type TournamentData, presetModeSchema } from "@/lib/validators/tournament";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useCreateTournamentStore } from "@/hooks/use-create-tournament-store";
import { AnimatePresence, motion } from "framer-motion";

const presetModes = presetModeSchema.options;

const presetDescriptions: { [key: string]: string } = {
    "Competitive Store": "डिफ़ॉल्ट स्टोर जिसमें सभी हथियार बैलेंस्ड तरीके से उपलब्ध होते हैं।",
    "Random Store": "हर राउंड में स्टोर में रैंडम हथियार आते हैं, जिससे गेम अप्रत्याशित हो जाता है।",
    "Crazy Store": "केवल सबसे शक्तिशाली और अनोखे हथियार (जैसे ग्रेनेड लॉन्चर) उपलब्ध होते हैं।",
    "Headshot Mode": "केवल हेडशॉट से ही डैमेज होता है, इसमें सटीकता बहुत महत्वपूर्ण है।",
    "CS Elite": "प्रो-प्ले के लिए सीमित हथियार, केवल AR और SMG गन्स ही मिलती हैं।"
};


export function Step3Rules({ form }: { form: UseFormReturn<TournamentData> }) {
  const { watch } = form;
  const { formData } = useCreateTournamentStore();

  const headshotOnly = watch("rules.headshotOnly");
  const matchType = formData.matchType;

  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <FormField
          control={form.control}
          name="rules.headshotOnly"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Headshot Only</FormLabel>
                <FormDescription>
                  यदि सक्षम किया गया है, तो केवल हेडशॉट से ही नुकसान होगा।
                </FormDescription>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="rules.unlimitedAmmo"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Unlimited Ammo</FormLabel>
                <FormDescription>
                  यदि सक्षम किया गया है, तो खिलाड़ियों के पास असीमित गोला-बारूद होगा।
                </FormDescription>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="rules.gunAttributes"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Gun Attributes</FormLabel>
                <FormDescription>
                  इन-गेम गन एट्रिब्यूट्स को सक्षम या अक्षम करें।
                </FormDescription>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <AnimatePresence>
        {!headshotOnly && (
            <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
            >
                <FormField
                control={form.control}
                name="rules.grenadeThrow"
                render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 mt-4">
                    <div className="space-y-0.5">
                        <FormLabel className="text-base">Grenade Throw</FormLabel>
                        <FormDescription>
                        ग्रेनेड फेंकने की अनुमति दें या न दें।
                        </FormDescription>
                    </div>
                    <FormControl>
                        <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        />
                    </FormControl>
                    </FormItem>
                )}
                />
            </motion.div>
        )}
        </AnimatePresence>

        <AnimatePresence>
        {matchType !== 'Solo' && (
             <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
            >
                <FormField
                    control={form.control}
                    name="rules.revive"
                    render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 mt-4">
                        <div className="space-y-0.5">
                            <FormLabel className="text-base">Revive</FormLabel>
                            <FormDescription>
                            टीम के साथियों को एक-दूसरे को रिवाइव करने की अनुमति दें।
                            </FormDescription>
                        </div>
                        <FormControl>
                            <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            />
                        </FormControl>
                        </FormItem>
                    )}
                />
            </motion.div>
        )}
        </AnimatePresence>
      </div>

      <FormField
        control={form.control}
        name="presetMode"
        render={({ field }) => (
          <FormItem className="space-y-3">
            <FormLabel className="text-base">Preset Mode</FormLabel>
            <FormDescription>
              इस टूर्नामेंट के लिए एक प्रीसेट गेम मोड चुनें।
            </FormDescription>
            <FormControl>
              <RadioGroup
                onValueChange={field.onChange}
                defaultValue={field.value}
                className="grid grid-cols-1 sm:grid-cols-2 gap-4"
              >
                {presetModes.map((mode) => (
                    <FormItem key={mode} className="flex flex-col">
                        <RadioGroupItem value={mode} id={mode} className="peer sr-only" />
                        <Label
                            htmlFor={mode}
                            className="flex flex-col items-center text-center justify-center rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                        >
                           <p className="font-bold text-base">{mode}</p>
                           <p className="text-xs text-muted-foreground mt-2">{presetDescriptions[mode]}</p>
                        </Label>
                    </FormItem>
                ))}
              </RadioGroup>
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    </div>
  );
}
