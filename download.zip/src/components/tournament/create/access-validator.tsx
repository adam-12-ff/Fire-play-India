
"use client";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { ShieldAlert, Timer } from "lucide-react";
import Link from "next/link";

type AccessValidatorProps = {
  isLoggedIn: boolean;
  hasGamingInfo: boolean;
  hasActiveTournament: boolean;
  cooldownTimeLeft: number;
  children: React.ReactNode;
};

export function AccessValidator({
  isLoggedIn,
  hasGamingInfo,
  hasActiveTournament,
  cooldownTimeLeft,
  children,
}: AccessValidatorProps) {

  if (!isLoggedIn) {
    return (
      <Alert variant="destructive">
        <ShieldAlert className="h-4 w-4" />
        <AlertTitle>Access Denied</AlertTitle>
        <AlertDescription>
          You must be logged in to create a tournament. Please log in and try again.
        </AlertDescription>
      </Alert>
    );
  }

  if (cooldownTimeLeft > 0) {
    const minutes = Math.floor(cooldownTimeLeft);
    const seconds = Math.floor((cooldownTimeLeft * 60) % 60);
    return (
      <Alert>
        <Timer className="h-4 w-4" />
        <AlertTitle>Cooldown Period Active</AlertTitle>
        <AlertDescription>
         आपको दूसरा टूर्नामेंट बनाने से पहले इंतजार करना होगा। शेष समय: {' '}
          <span className="font-bold text-accent">{String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}</span>.
        </AlertDescription>
      </Alert>
    );
  }


  if (!hasGamingInfo) {
    return (
      <Alert variant="destructive">
        <ShieldAlert className="h-4 w-4" />
        <AlertTitle>Gaming Info Required</AlertTitle>
        <AlertDescription>
         टूर्नामेंट होस्ट करने से पहले आपको अपनी गेमिंग जानकारी (UID, Level, Username) अपनी प्रोफ़ाइल में जोड़नी होगी।
           <Button asChild variant="link" className="p-0 h-auto ml-1 text-destructive hover:text-destructive/80">
                <Link href="/profile">Go to Profile</Link>
            </Button>
        </AlertDescription>
      </Alert>
    );
  }
  
  if (hasActiveTournament) {
    return (
      <Alert variant="destructive">
        <ShieldAlert className="h-4 w-4" />
        <AlertTitle>Tournament Limit Reached</AlertTitle>
        <AlertDescription>
          You can only host one tournament at a time. Please wait for your existing tournament to finish before creating a new one.
        </AlertDescription>
      </Alert>
    );
  }


  return <>{children}</>;
}
