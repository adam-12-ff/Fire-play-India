
"use client";

import { type UseFormReturn } from "react-hook-form";
import { type TournamentData } from "@/lib/validators/tournament";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  if (value === null || value === undefined) return null;
  return (
    <div className="flex justify-between items-center py-2">
      <p className="text-muted-foreground">{label}</p>
      <div className="font-semibold text-right">{value}</div>
    </div>
  );
}

export function Step5Confirm({ form }: { form: UseFormReturn<TournamentData> }) {
  const data = form.watch();

  return (
    <Card className="bg-card/50">
      <CardHeader>
        <CardTitle className="text-primary text-center">Review Your Tournament</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-1">
          <InfoRow label="Title" value={data.title} />
          <InfoRow label="Tournament ID" value={<span className="font-mono">{data.id}</span>} />
          <InfoRow label="Visibility" value={<span className="capitalize">{data.visibility}</span>} />
        </div>
        <Separator />
        <div className="space-y-1">
          <InfoRow label="Game Mode" value={data.gameMode} />
          <InfoRow label="Match Type" value={data.matchType} />
           {data.gameMode === 'CS' && <InfoRow label="Rounds" value={data.rounds} />}
          <InfoRow label="Max Players/Teams" value={data.maxPlayers} />
        </div>
        <Separator />
        <div className="space-y-1">
          <InfoRow label="Entry Fee" value={`${data.entryFee} Coins`} />
          <InfoRow label="Platform Fee" value={`${data.platformFee.toFixed(2)} Coins`} />
          <InfoRow label="Prize Pool" value={data.prizePool ? `${data.prizePool} Coins` : "None"} />
        </div>
        <Separator />
        <div className="space-y-1">
          <InfoRow label="Start Time" value={data.startTime ? format(data.startTime, "PPpp") : 'N/A'} />
          <InfoRow label="Headshot Only" value={<Badge variant={data.rules.headshotOnly ? "default" : "secondary"}>{data.rules.headshotOnly ? "Yes" : "No"}</Badge>} />
          <InfoRow label="Unlimited Ammo" value={<Badge variant={data.rules.unlimitedAmmo ? "default" : "secondary"}>{data.rules.unlimitedAmmo ? "Yes" : "No"}</Badge>} />
          <InfoRow label="Gun Attributes" value={<Badge variant={data.rules.gunAttributes ? "default" : "secondary"}>{data.rules.gunAttributes ? "Yes" : "No"}</Badge>} />
          <InfoRow label="Grenade Throw" value={<Badge variant={data.rules.grenadeThrow ? "default" : "secondary"}>{data.rules.grenadeThrow ? "Yes" : "No"}</Badge>} />
          <InfoRow label="Revive" value={<Badge variant={data.rules.revive ? "default" : "secondary"}>{data.rules.revive ? "Yes" : "No"}</Badge>} />
          <InfoRow label="Gun Card Support" value={<Badge variant={data.gunCardSupport ? "default" : "secondary"}>{data.gunCardSupport ? "Yes" : "No"}</Badge>} />
          <InfoRow label="Preset Mode" value={<Badge variant="outline">{data.presetMode}</Badge>} />
        </div>
      </CardContent>
    </Card>
  );
}
