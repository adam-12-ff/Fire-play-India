
"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useCreateTournamentStore } from "@/hooks/use-create-tournament-store";
import {
  tournamentSchema,
  type TournamentData,
} from "@/lib/validators/tournament";
import { Form } from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { AnimatePresence, motion } from "framer-motion";
import { Step1GameMode } from "./step-1-game-mode";
import { Step2Info } from "./step-2-info";
import { Step3Rules } from "./step-3-rules";
import { Step4GunCard } from "./step-4-gun-card";
import { FormNavigation } from "./form-navigation";
import { generateTournamentId } from "@/lib/tournament-utils";
import { doc, setDoc, serverTimestamp, updateDoc } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { useRouter } from "next/navigation";
import { useAuthState } from "react-firebase-hooks/auth";
import { useState } from "react";

const steps = [
  { id: "Step 1", name: "Game Mode", component: Step1GameMode },
  { id: "Step 2", name: "Information", component: Step2Info },
  { id: "Step 3", name: "Rules", component: Step3Rules },
  { id: "Step 4", name: "Confirmation", component: Step4GunCard },
];

export function CreateTournamentForm() {
  const { currentStep, formData, setFormData, nextStep, prevStep, reset } =
    useCreateTournamentStore();
  const { toast } = useToast();
  const router = useRouter();
  const [user] = useAuthState(auth);
  const [isSubmitting, setIsSubmitting] = useState(false);


  const form = useForm<TournamentData>({
    resolver: zodResolver(tournamentSchema),
    defaultValues: {
      ...formData,
      id: formData.id || generateTournamentId(),
    },
    mode: "onChange",
  });

  const processForm = async (data: TournamentData) => {
    // This function is now only for the final submission
    if (currentStep !== steps.length || !user) {
        toast({ variant: "destructive", title: "Error", description: "You must be logged in to create a tournament." });
        return;
    }
    
    setIsSubmitting(true);
    
    try {
      const tournamentDocRef = doc(db, "tournaments", data.id);
      const userDocRef = doc(db, "users", user.uid);
      
      await setDoc(tournamentDocRef, {
        ...data,
        hostId: user.uid,
        hostName: user.displayName,
        createdAt: serverTimestamp(),
        participants: [],
        status: "pending"
      });

      await updateDoc(userDocRef, {
        lastTournamentCreationTime: serverTimestamp()
      });

      toast({
        title: "Tournament Created!",
        description: "Your tournament is now live in the lobby."
      });
      reset(); // Reset form state
      router.push('/');
    } catch (error) {
      console.error("Error creating tournament:", error);
      toast({ variant: "destructive", title: "Creation Failed", description: "Could not create the tournament." });
      setIsSubmitting(false); // Ensure loader stops on error
    }
  };

  const CurrentStepComponent = steps[currentStep - 1].component;
  const progress = ((currentStep - 1) / (steps.length - 1)) * 100;

  return (
    <Card className="border-primary/20 shadow-xl shadow-primary/10">
      <CardContent className="p-4 sm:p-6">
        <div className="mb-6">
          <p className="text-sm font-medium text-primary">
            Step {currentStep} of {steps.length}: {steps[currentStep-1].name}
          </p>
          <Progress value={progress} className="mt-2 h-2 [&>div]:bg-primary" />
        </div>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(processForm)}>
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.3 }}
              >
                <CurrentStepComponent form={form} />
              </motion.div>
            </AnimatePresence>

            <FormNavigation isSubmitting={isSubmitting} />
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
