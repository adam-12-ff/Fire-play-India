import { Flame } from 'lucide-react';
import { cn } from '@/lib/utils';
import Link from 'next/link';

export function Logo({ className, inLink = false }: { className?: string, inLink?: boolean }) {
  const content = (
      <div className={cn("flex items-center gap-2 text-2xl font-bold text-white", className)}>
        <Flame className="text-primary h-7 w-7 neon-primary" />
        <span className="font-headline tracking-tighter">
          Fire<span className="text-primary">Play</span>
        </span>
      </div>
  )
  
  if (inLink) {
    return <Link href="/">{content}</Link>;
  }

  return content;
}
