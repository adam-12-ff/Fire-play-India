
'use client';

import { Bell, Wallet, LogOut, Menu, Home, Swords, PlusCircle, User as UserIcon, Store, Bot, HelpCircle } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/core/logo";
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth, db } from '@/lib/firebase';
import { signOut } from 'firebase/auth';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { doc, onSnapshot } from "firebase/firestore";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Sheet, SheetContent, SheetHeader, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";

const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/matches", label: "My Matches", icon: Swords },
    { href: "/create-tournament", label: "Create Room", icon: PlusCircle },
    { href: "/store", label: "Store", icon: Store },
    { href: "/wallet", label: "Wallet", icon: Wallet },
    { href: "/profile", label: "Profile", icon: UserIcon },
    { href: "/how-it-works", label: "How it Works", icon: HelpCircle },
];

export function MainHeader() {
  const [user, loading] = useAuthState(auth);
  const router = useRouter();
  const { toast } = useToast();
  const [userData, setUserData] = useState<any>(null);
  const [isSheetOpen, setIsSheetOpen] = useState(false);

  useEffect(() => {
    if (user) {
      const unsub = onSnapshot(doc(db, "users", user.uid), (doc) => {
        if (doc.exists()) {
          setUserData(doc.data());
        }
      });
      return () => unsub();
    }
  }, [user]);

  const handleLogout = async () => {
    setIsSheetOpen(false);
    await signOut(auth);
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out.",
    });
    router.push('/login');
  };

  if (loading) {
    return (
       <header className="sticky top-0 z-40 w-full bg-background/80 backdrop-blur-sm border-b border-border/50">
        <div className="container flex h-16 items-center justify-between px-4 sm:px-6">
          <Logo inLink />
        </div>
      </header>
    )
  }
  
  if (!user) {
     return (
       <header className="sticky top-0 z-40 w-full bg-background/80 backdrop-blur-sm border-b border-border/50">
        <div className="container flex h-16 items-center justify-between px-4 sm:px-6">
          <Logo inLink />
           <Button asChild>
            <Link href="/login">Login</Link>
          </Button>
        </div>
      </header>
    )
  }
  
  const avatarUrl = `https://source.boringavatars.com/beam/120/${user.uid}?colors=A020F0,7CFC00,FFFFFF,1f2128,262931`;

  return (
    <header className="sticky top-0 z-40 w-full bg-background/80 backdrop-blur-sm border-b border-border/50">
      <div className="container flex h-16 items-center justify-between px-4 sm:px-6">
        <div className="flex items-center gap-4">
             <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
                <SheetTrigger asChild>
                    <Button variant="ghost" size="icon" className="md:hidden">
                        <Menu className="h-6 w-6" />
                        <span className="sr-only">Open Menu</span>
                    </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0">
                    <SheetHeader className="p-4 border-b">
                         <SheetTitle>
                            <Logo inLink />
                         </SheetTitle>
                    </SheetHeader>
                    <div className="p-4 space-y-4">
                        <Link href="/profile" className="flex items-center gap-3" onClick={() => setIsSheetOpen(false)}>
                             <Avatar className="h-12 w-12 border-2 border-primary">
                                <AvatarImage src={avatarUrl} alt="User Avatar" />
                                <AvatarFallback>{user.displayName?.charAt(0) || 'U'}</AvatarFallback>
                            </Avatar>
                            <div>
                                <p className="font-semibold">{userData?.name || user.displayName}</p>
                                <p className="text-sm text-muted-foreground">View Profile</p>
                            </div>
                        </Link>
                        <div className="flex items-center gap-2 rounded-lg border border-border bg-card p-3 text-sm font-semibold">
                            <Wallet className="h-6 w-6 neon-accent" />
                            <span className="text-accent">{userData?.walletBalance?.toFixed(2) || '0.00'} Coins</span>
                        </div>
                    </div>
                    <Separator />
                     <nav className="p-4 space-y-2">
                        {navItems.map((item) => (
                            <Button key={item.label} asChild variant="ghost" className="w-full justify-start text-base h-12">
                                <Link href={item.href} onClick={() => setIsSheetOpen(false)}>
                                    <item.icon className="mr-3 h-5 w-5 text-muted-foreground" />
                                    {item.label}
                                </Link>
                            </Button>
                        ))}
                    </nav>
                    <div className="absolute bottom-4 left-4 right-4">
                         <Button variant="destructive" className="w-full h-12" onClick={handleLogout}>
                            <LogOut className="mr-2 h-5 w-5" />
                            Log Out
                        </Button>
                    </div>
                </SheetContent>
            </Sheet>
            <Logo inLink />
        </div>
        
        <div className="hidden md:flex items-center gap-4">
             <Link href="/wallet">
                <div className="flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-sm font-semibold cursor-pointer hover:border-primary transition-colors">
                <Wallet className="h-5 w-5 neon-accent" />
                <span className="text-accent">{userData?.walletBalance?.toFixed(2) || '0.00'} Coins</span>
                </div>
            </Link>
             <Button asChild variant="ghost" size="icon" className="rounded-full">
                <Link href="/how-it-works">
                  <HelpCircle className="h-6 w-6 text-muted-foreground hover:text-foreground transition-colors" />
                  <span className="sr-only">How it Works</span>
                </Link>
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full">
                <Bell className="h-6 w-6 text-muted-foreground hover:text-foreground transition-colors" />
                <span className="sr-only">Notifications</span>
            </Button>
        </div>

        <div className="flex items-center gap-4">
           <Link href="/profile">
            <Avatar className="h-9 w-9 border-2 border-primary cursor-pointer">
              <AvatarImage src={avatarUrl} alt="User Avatar" />
              <AvatarFallback>{user.displayName?.charAt(0) || 'U'}</AvatarFallback>
            </Avatar>
          </Link>
           <Button variant="ghost" size="icon" onClick={handleLogout} className="rounded-full hidden md:flex">
            <LogOut className="h-6 w-6 text-muted-foreground hover:text-destructive transition-colors" />
            <span className="sr-only">Logout</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
