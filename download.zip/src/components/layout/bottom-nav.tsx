
'use client';

import Link from "next/link";
import { usePathname } from "next/navigation";
import { NavHomeIcon, NavMatchesIcon, NavCreateIcon, NavWalletIcon, NavProfileIcon, NavStoreIcon } from "@/components/icons";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const pathname = usePathname();

  const navItems = [
    { href: "/", label: "Home", icon: NavHomeIcon },
    { href: "/matches", label: "Matches", icon: NavMatchesIcon },
    { href: "/create-tournament", label: "Create", icon: NavCreateIcon },
    { href: "/wallet", label: "Wallet", icon: NavWalletIcon },
    { href: "/profile", label: "Profile", icon: NavProfileIcon },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 h-20 border-t border-border/50 bg-background/80 p-2 backdrop-blur-sm md:hidden">
      <div className="grid h-full grid-cols-5 items-center">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link key={item.href} href={item.href} className="group flex flex-col items-center justify-center gap-1 text-center">
              <item.icon isActive={isActive} />
              <span className={cn(
                "text-xs font-medium transition-colors",
                isActive ? 'text-accent' : 'text-muted-foreground group-hover:text-foreground'
              )}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
