
import { cn } from "@/lib/utils";
import { 
  Home, 
  Swords, 
  PlusCircle, 
  Wallet, 
  User, 
  Crown,
  Users,
  Ticket,
  Store,
  type LucideProps
} from "lucide-react";

type IconProps = LucideProps & {
  isActive?: boolean;
};

const commonCls = "h-7 w-7 transition-all duration-300";
const activeCls = "text-accent drop-shadow-[0_0_8px_theme(colors.accent.DEFAULT)] scale-110";
const inactiveCls = "text-muted-foreground group-hover:text-foreground";

export const NavHomeIcon = ({isActive, className, ...props}: IconProps) => (
  <Home className={cn(commonCls, isActive ? activeCls : inactiveCls, className)} {...props} />
);

export const NavMatchesIcon = ({isActive, className, ...props}: IconProps) => (
  <Swords className={cn(commonCls, isActive ? activeCls : inactiveCls, className)} {...props} />
);

export const NavCreateIcon = ({isActive, className, ...props}: IconProps) => (
  <PlusCircle className={cn(commonCls, "h-8 w-8", isActive ? activeCls : inactiveCls, className)} {...props} />
);

export const NavWalletIcon = ({isActive, className, ...props}: IconProps) => (
  <Wallet className={cn(commonCls, isActive ? activeCls : inactiveCls, className)} {...props} />
);

export const NavProfileIcon = ({isActive, className, ...props}: IconProps) => (
  <User className={cn(commonCls, isActive ? activeCls : inactiveCls, className)} {...props} />
);

export const NavStoreIcon = ({isActive, className, ...props}: IconProps) => (
  <Store className={cn(commonCls, isActive ? activeCls : inactiveCls, className)} {...props} />
);


export const SoloIcon = (props: LucideProps) => (
  <Crown className="h-4 w-4 text-amber-400" {...props} />
);

export const TeamIcon = (props: LucideProps) => (
  <Users className="h-4 w-4 text-sky-400" {...props} />
);
