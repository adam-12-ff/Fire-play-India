import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export function TournamentCardSkeleton() {
  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="p-0">
        <Skeleton className="h-40 w-full" />
      </CardHeader>
      <CardContent className="p-4 space-y-4 flex-grow">
        <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-5 w-3/4" />
            </div>
             <div className="space-y-2">
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-5 w-3/4" />
            </div>
        </div>
        <div className="space-y-2">
            <Skeleton className="h-4 w-1/3" />
            <Skeleton className="h-2 w-full" />
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Skeleton className="h-11 w-full" />
      </CardFooter>
    </Card>
  );
}
